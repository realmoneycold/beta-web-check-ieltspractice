--
-- PostgreSQL database dump
--

\restrict hgHBsDwEQteZEmbhHY65MqAOjw5730TD3zzZgRdPbWnOJGksKxmQSuOhQuEbliG

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: ApplicationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ApplicationStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'DECLINED'
);


ALTER TYPE public."ApplicationStatus" OWNER TO postgres;

--
-- Name: DeviceType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DeviceType" AS ENUM (
    'DESKTOP',
    'LAPTOP',
    'MOBILE',
    'TABLET'
);


ALTER TYPE public."DeviceType" OWNER TO postgres;

--
-- Name: GroupLevel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."GroupLevel" AS ENUM (
    'BEGINNER',
    'INTERMEDIATE',
    'ADVANCED'
);


ALTER TYPE public."GroupLevel" OWNER TO postgres;

--
-- Name: GroupStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."GroupStatus" AS ENUM (
    'OPEN',
    'CLOSED'
);


ALTER TYPE public."GroupStatus" OWNER TO postgres;

--
-- Name: LeaderboardCategory; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."LeaderboardCategory" AS ENUM (
    'HIGHEST_SCORER',
    'TYPING_DOJO',
    'STUDY_STREAK',
    'WEEKLY_TEST'
);


ALTER TYPE public."LeaderboardCategory" OWNER TO postgres;

--
-- Name: PartnerStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PartnerStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."PartnerStatus" OWNER TO postgres;

--
-- Name: PracticeMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PracticeMode" AS ENUM (
    'FULL',
    'PARTIAL'
);


ALTER TYPE public."PracticeMode" OWNER TO postgres;

--
-- Name: QuestionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QuestionType" AS ENUM (
    'MULTIPLE_CHOICE',
    'FILL_BLANKS',
    'TRUE_FALSE'
);


ALTER TYPE public."QuestionType" OWNER TO postgres;

--
-- Name: ReportStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ReportStatus" AS ENUM (
    'OPEN',
    'REVIEWING',
    'RESOLVED',
    'WONT_FIX'
);


ALTER TYPE public."ReportStatus" OWNER TO postgres;

--
-- Name: ReportType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ReportType" AS ENUM (
    'CONTENT_ERROR',
    'TECHNICAL_BUG',
    'SCORE_ERROR',
    'TYPO',
    'OTHER'
);


ALTER TYPE public."ReportType" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'STUDENT',
    'ADMIN',
    'CEO',
    'CENTRE',
    'TEACHER',
    'GRADER',
    'SUPPORT',
    'CONTENT',
    'ANALYST',
    'MANAGER'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: SkillArea; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."SkillArea" AS ENUM (
    'READING_COMPREHENSION',
    'LISTENING_COMPREHENSION',
    'WRITING_TASK_1',
    'WRITING_TASK_2',
    'SPEAKING_PART_1',
    'SPEAKING_PART_2',
    'SPEAKING_PART_3',
    'VOCABULARY',
    'GRAMMAR',
    'PRONUNCIATION',
    'FLUENCY',
    'COHERENCE'
);


ALTER TYPE public."SkillArea" OWNER TO postgres;

--
-- Name: TaskLabel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskLabel" AS ENUM (
    'CUSTOMER_SERVICE',
    'TECHNICAL_ANALYSIS',
    'CONTENT_MANAGEMENT',
    'OPERATIONS'
);


ALTER TYPE public."TaskLabel" OWNER TO postgres;

--
-- Name: TaskPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskPriority" AS ENUM (
    'HIGH',
    'MEDIUM',
    'LOW'
);


ALTER TYPE public."TaskPriority" OWNER TO postgres;

--
-- Name: TestStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TestStatus" AS ENUM (
    'COMPLETED',
    'ABANDONED',
    'IN_PROGRESS'
);


ALTER TYPE public."TestStatus" OWNER TO postgres;

--
-- Name: TestType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TestType" AS ENUM (
    'READING',
    'LISTENING',
    'WRITING',
    'SPEAKING'
);


ALTER TYPE public."TestType" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AIWritingAssessment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AIWritingAssessment" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "writingText" text NOT NULL,
    "taskType" text DEFAULT 'Task2'::text NOT NULL,
    assessment jsonb NOT NULL,
    "overallBand" double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AIWritingAssessment" OWNER TO postgres;

--
-- Name: AIWritingAssessment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AIWritingAssessment_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AIWritingAssessment_id_seq" OWNER TO postgres;

--
-- Name: AIWritingAssessment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AIWritingAssessment_id_seq" OWNED BY public."AIWritingAssessment".id;


--
-- Name: AdminTask; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AdminTask" (
    id integer NOT NULL,
    "adminId" integer NOT NULL,
    title text NOT NULL,
    notes text,
    label public."TaskLabel" DEFAULT 'CUSTOMER_SERVICE'::public."TaskLabel" NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "isDone" boolean DEFAULT false NOT NULL,
    "doneAt" timestamp(3) without time zone,
    "assignedDate" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AdminTask" OWNER TO postgres;

--
-- Name: AdminTask_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AdminTask_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AdminTask_id_seq" OWNER TO postgres;

--
-- Name: AdminTask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AdminTask_id_seq" OWNED BY public."AdminTask".id;


--
-- Name: AiChatSession; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AiChatSession" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    topic text DEFAULT 'General'::text NOT NULL,
    "messageCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    history jsonb,
    category text DEFAULT 'General'::text NOT NULL,
    question text,
    response text
);


ALTER TABLE public."AiChatSession" OWNER TO postgres;

--
-- Name: AiChatSession_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AiChatSession_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AiChatSession_id_seq" OWNER TO postgres;

--
-- Name: AiChatSession_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AiChatSession_id_seq" OWNED BY public."AiChatSession".id;


--
-- Name: Device; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Device" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "deviceType" public."DeviceType" DEFAULT 'DESKTOP'::public."DeviceType" NOT NULL,
    "deviceName" text NOT NULL,
    browser text NOT NULL,
    os text,
    "ipAddress" text,
    location text,
    latitude double precision,
    longitude double precision,
    "userAgent" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastActiveAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Device" OWNER TO postgres;

--
-- Name: Device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Device_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Device_id_seq" OWNER TO postgres;

--
-- Name: Device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Device_id_seq" OWNED BY public."Device".id;


--
-- Name: Follow; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Follow" (
    id integer NOT NULL,
    "studentId" integer NOT NULL,
    "teacherId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Follow" OWNER TO postgres;

--
-- Name: Follow_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Follow_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Follow_id_seq" OWNER TO postgres;

--
-- Name: Follow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Follow_id_seq" OWNED BY public."Follow".id;


--
-- Name: GroupApplication; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupApplication" (
    id integer NOT NULL,
    "studentId" integer NOT NULL,
    "groupId" integer NOT NULL,
    status public."ApplicationStatus" DEFAULT 'PENDING'::public."ApplicationStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."GroupApplication" OWNER TO postgres;

--
-- Name: GroupApplication_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupApplication_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupApplication_id_seq" OWNER TO postgres;

--
-- Name: GroupApplication_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupApplication_id_seq" OWNED BY public."GroupApplication".id;


--
-- Name: Inquiry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Inquiry" (
    id integer NOT NULL,
    "centreId" integer NOT NULL,
    "studentName" text NOT NULL,
    "studentEmail" text NOT NULL,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Inquiry" OWNER TO postgres;

--
-- Name: Inquiry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Inquiry_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Inquiry_id_seq" OWNER TO postgres;

--
-- Name: Inquiry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Inquiry_id_seq" OWNED BY public."Inquiry".id;


--
-- Name: Lesson; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Lesson" (
    id integer NOT NULL,
    title text NOT NULL,
    "zoomLink" text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'SCHEDULED'::text NOT NULL,
    "teacherId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Lesson" OWNER TO postgres;

--
-- Name: Lesson_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Lesson_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Lesson_id_seq" OWNER TO postgres;

--
-- Name: Lesson_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Lesson_id_seq" OWNED BY public."Lesson".id;


--
-- Name: LoginLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoginLog" (
    id integer NOT NULL,
    "userId" integer,
    "ipAddress" text,
    "deviceInfo" text,
    "userAgent" text,
    success boolean NOT NULL,
    reason text,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoginLog" OWNER TO postgres;

--
-- Name: LoginLog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LoginLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."LoginLog_id_seq" OWNER TO postgres;

--
-- Name: LoginLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LoginLog_id_seq" OWNED BY public."LoginLog".id;


--
-- Name: Material; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Material" (
    id integer NOT NULL,
    "fileName" text NOT NULL,
    "fileUrl" text NOT NULL,
    "fileType" text NOT NULL,
    "teacherId" integer NOT NULL,
    "lessonId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Material" OWNER TO postgres;

--
-- Name: Material_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Material_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Material_id_seq" OWNER TO postgres;

--
-- Name: Material_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Material_id_seq" OWNED BY public."Material".id;


--
-- Name: MockResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MockResult" (
    id integer NOT NULL,
    "studentId" integer NOT NULL,
    "sessionId" integer,
    listening double precision,
    reading double precision,
    writing double precision,
    speaking double precision,
    overall double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MockResult" OWNER TO postgres;

--
-- Name: MockResult_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MockResult_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MockResult_id_seq" OWNER TO postgres;

--
-- Name: MockResult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MockResult_id_seq" OWNED BY public."MockResult".id;


--
-- Name: MockSession; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MockSession" (
    id integer NOT NULL,
    "centreId" integer NOT NULL,
    "dateTime" timestamp(3) without time zone NOT NULL,
    type text DEFAULT 'Academic'::text NOT NULL,
    format text DEFAULT 'Paper-Based'::text NOT NULL,
    location text DEFAULT 'TBD'::text NOT NULL,
    capacity integer DEFAULT 30 NOT NULL,
    price double precision DEFAULT 0 NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MockSession" OWNER TO postgres;

--
-- Name: MockSession_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MockSession_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MockSession_id_seq" OWNER TO postgres;

--
-- Name: MockSession_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MockSession_id_seq" OWNED BY public."MockSession".id;


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id integer NOT NULL,
    icon text DEFAULT '🔔'::text NOT NULL,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: Notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Notification_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Notification_id_seq" OWNER TO postgres;

--
-- Name: Notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Notification_id_seq" OWNED BY public."Notification".id;


--
-- Name: PartnerRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PartnerRequest" (
    id integer NOT NULL,
    centre_name text NOT NULL,
    ceo_name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    location text NOT NULL,
    status public."PartnerStatus" DEFAULT 'PENDING'::public."PartnerStatus" NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PartnerRequest" OWNER TO postgres;

--
-- Name: PartnerRequest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PartnerRequest_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PartnerRequest_id_seq" OWNER TO postgres;

--
-- Name: PartnerRequest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PartnerRequest_id_seq" OWNED BY public."PartnerRequest".id;


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordResetToken" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordResetToken" OWNER TO postgres;

--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PasswordResetToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PasswordResetToken_id_seq" OWNER TO postgres;

--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PasswordResetToken_id_seq" OWNED BY public."PasswordResetToken".id;


--
-- Name: PracticeTest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PracticeTest" (
    id integer NOT NULL,
    title text NOT NULL,
    "testType" public."TestType" NOT NULL,
    "practiceMode" public."PracticeMode" DEFAULT 'FULL'::public."PracticeMode" NOT NULL,
    "focusArea" text,
    "durationMins" integer DEFAULT 60 NOT NULL,
    instructions text,
    passage text,
    "audioUrl" text,
    "isPublished" boolean DEFAULT false NOT NULL,
    "isArchived" boolean DEFAULT false NOT NULL,
    "createdById" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PracticeTest" OWNER TO postgres;

--
-- Name: PracticeTestResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PracticeTestResult" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "testId" integer NOT NULL,
    "testIdentifier" text NOT NULL,
    "testCategory" text NOT NULL,
    "testSubcategory" text,
    "setNumber" integer NOT NULL,
    score double precision DEFAULT 0 NOT NULL,
    "bandScore" double precision,
    "correctAnswers" integer DEFAULT 0 NOT NULL,
    "totalQuestions" integer DEFAULT 0 NOT NULL,
    "timeSpentSeconds" integer DEFAULT 0 NOT NULL,
    answers jsonb,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "isUnlocked" boolean DEFAULT true NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "aiAnalysis" text,
    "progressNote" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PracticeTestResult" OWNER TO postgres;

--
-- Name: PracticeTestResult_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PracticeTestResult_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PracticeTestResult_id_seq" OWNER TO postgres;

--
-- Name: PracticeTestResult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PracticeTestResult_id_seq" OWNED BY public."PracticeTestResult".id;


--
-- Name: PracticeTest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PracticeTest_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PracticeTest_id_seq" OWNER TO postgres;

--
-- Name: PracticeTest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PracticeTest_id_seq" OWNED BY public."PracticeTest".id;


--
-- Name: ProgressSnapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProgressSnapshot" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "listeningAvg" double precision DEFAULT 0,
    "readingAvg" double precision DEFAULT 0,
    "writingAvg" double precision DEFAULT 0,
    "speakingAvg" double precision DEFAULT 0,
    "overallAvg" double precision DEFAULT 0,
    "estimatedBand" double precision DEFAULT 5.0,
    "targetBand" double precision DEFAULT 8.0,
    "testsCompleted" integer DEFAULT 0 NOT NULL,
    "currentStreak" integer DEFAULT 0 NOT NULL,
    "bestStreak" integer DEFAULT 0 NOT NULL,
    "weakAreas" text,
    "strongAreas" text,
    "isMakingProgress" boolean DEFAULT true NOT NULL,
    "aiConclusion" text,
    recommendation text,
    "snapshotDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProgressSnapshot" OWNER TO postgres;

--
-- Name: ProgressSnapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProgressSnapshot_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProgressSnapshot_id_seq" OWNER TO postgres;

--
-- Name: ProgressSnapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProgressSnapshot_id_seq" OWNED BY public."ProgressSnapshot".id;


--
-- Name: Question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Question" (
    id integer NOT NULL,
    "testId" integer NOT NULL,
    "questionText" text NOT NULL,
    type public."QuestionType" DEFAULT 'MULTIPLE_CHOICE'::public."QuestionType" NOT NULL,
    options jsonb,
    "correctAnswer" text NOT NULL,
    "orderIndex" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Question" OWNER TO postgres;

--
-- Name: Question_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Question_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Question_id_seq" OWNER TO postgres;

--
-- Name: Question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Question_id_seq" OWNED BY public."Question".id;


--
-- Name: Report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Report" (
    id integer NOT NULL,
    "studentId" integer NOT NULL,
    "testId" integer NOT NULL,
    "questionId" integer,
    type public."ReportType" DEFAULT 'CONTENT_ERROR'::public."ReportType" NOT NULL,
    status public."ReportStatus" DEFAULT 'OPEN'::public."ReportStatus" NOT NULL,
    description text NOT NULL,
    "resolvedById" integer,
    "resolutionNote" text,
    "resolvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Report" OWNER TO postgres;

--
-- Name: Report_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Report_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Report_id_seq" OWNER TO postgres;

--
-- Name: Report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Report_id_seq" OWNED BY public."Report".id;


--
-- Name: StrategicGoal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StrategicGoal" (
    id integer NOT NULL,
    title text NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "column" text DEFAULT 'TODO'::text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StrategicGoal" OWNER TO postgres;

--
-- Name: StrategicGoal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."StrategicGoal_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StrategicGoal_id_seq" OWNER TO postgres;

--
-- Name: StrategicGoal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."StrategicGoal_id_seq" OWNED BY public."StrategicGoal".id;


--
-- Name: StudyGroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StudyGroup" (
    id integer NOT NULL,
    "centreId" integer NOT NULL,
    "teacherId" integer,
    name text NOT NULL,
    level text DEFAULT 'All levels'::text NOT NULL,
    schedule text DEFAULT 'TBD'::text NOT NULL,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    capacity integer DEFAULT 15 NOT NULL,
    status public."GroupStatus" DEFAULT 'OPEN'::public."GroupStatus" NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StudyGroup" OWNER TO postgres;

--
-- Name: StudyGroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."StudyGroup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StudyGroup_id_seq" OWNER TO postgres;

--
-- Name: StudyGroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."StudyGroup_id_seq" OWNED BY public."StudyGroup".id;


--
-- Name: StudyStreak; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StudyStreak" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    date date NOT NULL,
    "isCompleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."StudyStreak" OWNER TO postgres;

--
-- Name: StudyStreak_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."StudyStreak_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StudyStreak_id_seq" OWNER TO postgres;

--
-- Name: StudyStreak_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."StudyStreak_id_seq" OWNED BY public."StudyStreak".id;


--
-- Name: TestUnlock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TestUnlock" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    category text NOT NULL,
    subcategory text,
    "maxUnlockedSet" integer DEFAULT 1 NOT NULL,
    "minScoreRequired" double precision DEFAULT 70.0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TestUnlock" OWNER TO postgres;

--
-- Name: TestUnlock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TestUnlock_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TestUnlock_id_seq" OWNER TO postgres;

--
-- Name: TestUnlock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TestUnlock_id_seq" OWNED BY public."TestUnlock".id;


--
-- Name: TypingResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TypingResult" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    wpm double precision NOT NULL,
    accuracy double precision NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "durationMinutes" integer DEFAULT 2,
    difficulty text DEFAULT 'intermediate'::text NOT NULL
);


ALTER TABLE public."TypingResult" OWNER TO postgres;

--
-- Name: TypingResult_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TypingResult_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TypingResult_id_seq" OWNER TO postgres;

--
-- Name: TypingResult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TypingResult_id_seq" OWNED BY public."TypingResult".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    full_name text NOT NULL,
    name text,
    email text NOT NULL,
    username text,
    password text,
    country text,
    phone text,
    test_type text,
    role public."Role" DEFAULT 'STUDENT'::public."Role" NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    "isVerified" boolean DEFAULT false,
    is_onboarded boolean DEFAULT false NOT NULL,
    "isOnboarded" boolean DEFAULT false,
    target_band double precision DEFAULT 8.0,
    "targetBand" double precision DEFAULT 8.0,
    current_band double precision DEFAULT 5.0 NOT NULL,
    "currentBand" double precision DEFAULT 5.0,
    study_hours double precision DEFAULT 0 NOT NULL,
    tasks_done integer DEFAULT 0 NOT NULL,
    "tasksDone" integer DEFAULT 0,
    weekly_goal_percent double precision DEFAULT 0 NOT NULL,
    exam_date timestamp(3) without time zone,
    "examDate" timestamp(3) without time zone,
    exam_date_text text,
    target_band_range text,
    study_commitment text,
    referral_source text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastSeenAt" timestamp(3) without time zone,
    "isExamDateUnsure" boolean DEFAULT true NOT NULL,
    "sourceOfExposure" text,
    "onboardingComplete" boolean DEFAULT false NOT NULL,
    "centreId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: VerificationCode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VerificationCode" (
    id integer NOT NULL,
    email text NOT NULL,
    code text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."VerificationCode" OWNER TO postgres;

--
-- Name: VerificationCode_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VerificationCode_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."VerificationCode_id_seq" OWNER TO postgres;

--
-- Name: VerificationCode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VerificationCode_id_seq" OWNED BY public."VerificationCode".id;


--
-- Name: WeeklyProgress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WeeklyProgress" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "weekStartDate" date NOT NULL,
    "perfectScoresCount" integer DEFAULT 0 NOT NULL,
    "progressPercentage" double precision DEFAULT 0 NOT NULL
);


ALTER TABLE public."WeeklyProgress" OWNER TO postgres;

--
-- Name: WeeklyProgress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."WeeklyProgress_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."WeeklyProgress_id_seq" OWNER TO postgres;

--
-- Name: WeeklyProgress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."WeeklyProgress_id_seq" OWNED BY public."WeeklyProgress".id;


--
-- Name: _Staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_Staff" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_Staff" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    "userId" integer NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcements (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    type text DEFAULT 'GENERAL'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" integer NOT NULL
);


ALTER TABLE public.announcements OWNER TO postgres;

--
-- Name: centres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.centres (
    id integer NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    city text NOT NULL,
    address text,
    phone text,
    website text,
    "totalStudents" integer DEFAULT 0 NOT NULL,
    "activeStudents" integer DEFAULT 0 NOT NULL,
    rating double precision DEFAULT 4.5,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    country text NOT NULL,
    email text,
    "managerId" integer,
    latitude double precision,
    longitude double precision
);


ALTER TABLE public.centres OWNER TO postgres;

--
-- Name: centres_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.centres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.centres_id_seq OWNER TO postgres;

--
-- Name: centres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.centres_id_seq OWNED BY public.centres.id;


--
-- Name: daily_study_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.daily_study_logs (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "studyDate" timestamp(3) without time zone NOT NULL,
    "testsCompleted" integer DEFAULT 0 NOT NULL,
    "timeSpentMinutes" integer DEFAULT 0 NOT NULL,
    "skillsPracticed" text[],
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.daily_study_logs OWNER TO postgres;

--
-- Name: daily_study_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.daily_study_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.daily_study_logs_id_seq OWNER TO postgres;

--
-- Name: daily_study_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.daily_study_logs_id_seq OWNED BY public.daily_study_logs.id;


--
-- Name: leaderboard_entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leaderboard_entries (
    id integer NOT NULL,
    "leaderboardId" integer NOT NULL,
    "userId" integer NOT NULL,
    rank integer NOT NULL,
    score double precision NOT NULL,
    trend text DEFAULT 'stable'::text NOT NULL,
    "trendAmount" integer DEFAULT 0 NOT NULL,
    "userName" text NOT NULL,
    "userCountry" text,
    "userAvatar" text,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.leaderboard_entries OWNER TO postgres;

--
-- Name: leaderboard_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leaderboard_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.leaderboard_entries_id_seq OWNER TO postgres;

--
-- Name: leaderboard_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leaderboard_entries_id_seq OWNED BY public.leaderboard_entries.id;


--
-- Name: leaderboards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.leaderboards (
    id integer NOT NULL,
    category public."LeaderboardCategory" NOT NULL,
    title text NOT NULL,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.leaderboards OWNER TO postgres;

--
-- Name: leaderboards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.leaderboards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.leaderboards_id_seq OWNER TO postgres;

--
-- Name: leaderboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.leaderboards_id_seq OWNED BY public.leaderboards.id;


--
-- Name: live_session_participants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.live_session_participants (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "userId" integer NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "leftAt" timestamp(3) without time zone,
    role text DEFAULT 'student'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.live_session_participants OWNER TO postgres;

--
-- Name: live_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.live_sessions (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "teacherId" integer NOT NULL,
    "sessionType" text DEFAULT 'speaking'::text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone,
    "maxParticipants" integer DEFAULT 20 NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    "isFeatured" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.live_sessions OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" integer NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: skill_statistics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skill_statistics (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    skill public."TestType" NOT NULL,
    "totalAttempts" integer DEFAULT 0 NOT NULL,
    "completedAttempts" integer DEFAULT 0 NOT NULL,
    "averageScore" double precision DEFAULT 0 NOT NULL,
    "bestScore" double precision DEFAULT 0 NOT NULL,
    "worstScore" double precision DEFAULT 0 NOT NULL,
    "totalTimeSpentSeconds" integer DEFAULT 0 NOT NULL,
    "averageTimeSpentSeconds" integer DEFAULT 0 NOT NULL,
    "improvementRate" double precision DEFAULT 0 NOT NULL,
    "consistencyScore" double precision DEFAULT 0 NOT NULL,
    "lastAttemptAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.skill_statistics OWNER TO postgres;

--
-- Name: skill_statistics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.skill_statistics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.skill_statistics_id_seq OWNER TO postgres;

--
-- Name: skill_statistics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.skill_statistics_id_seq OWNED BY public.skill_statistics.id;


--
-- Name: test_attempts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_attempts (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "testType" public."TestType" NOT NULL,
    "testId" text NOT NULL,
    "testName" text NOT NULL,
    "skillArea" text,
    score double precision,
    "maxScore" double precision DEFAULT 9.0 NOT NULL,
    "percentageScore" double precision,
    "timeSpentSeconds" integer,
    status public."TestStatus" DEFAULT 'COMPLETED'::public."TestStatus" NOT NULL,
    "answersCorrect" integer,
    "answersTotal" integer,
    feedback text,
    "completedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.test_attempts OWNER TO postgres;

--
-- Name: test_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.test_attempts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.test_attempts_id_seq OWNER TO postgres;

--
-- Name: test_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.test_attempts_id_seq OWNED BY public.test_attempts.id;


--
-- Name: test_submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_submissions (
    id text NOT NULL,
    "userId" integer NOT NULL,
    "testId" text NOT NULL,
    "testType" public."TestType" NOT NULL,
    answers jsonb NOT NULL,
    score double precision NOT NULL,
    "bandScore" double precision,
    "timeSpent" integer NOT NULL,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "gradedAt" timestamp(3) without time zone,
    feedback jsonb
);


ALTER TABLE public.test_submissions OWNER TO postgres;

--
-- Name: typing_practice_texts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.typing_practice_texts (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    difficulty text DEFAULT 'intermediate'::text NOT NULL,
    "wordCount" integer NOT NULL,
    topics text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.typing_practice_texts OWNER TO postgres;

--
-- Name: user_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_progress (
    id text NOT NULL,
    "userId" integer NOT NULL,
    "testType" public."TestType" NOT NULL,
    "latestScore" double precision NOT NULL,
    "testsCompleted" integer DEFAULT 0 NOT NULL,
    "lastTestDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_progress OWNER TO postgres;

--
-- Name: user_study_streaks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_study_streaks (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "currentStreak" integer DEFAULT 0 NOT NULL,
    "longestStreak" integer DEFAULT 0 NOT NULL,
    "totalStudyDays" integer DEFAULT 0 NOT NULL,
    "lastStudyDate" timestamp(3) without time zone,
    "weeklyGoal" integer DEFAULT 5 NOT NULL,
    "weeklyProgress" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_study_streaks OWNER TO postgres;

--
-- Name: user_study_streaks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_study_streaks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_study_streaks_id_seq OWNER TO postgres;

--
-- Name: user_study_streaks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_study_streaks_id_seq OWNED BY public.user_study_streaks.id;


--
-- Name: weakness_analysis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weakness_analysis (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "skillArea" public."SkillArea" NOT NULL,
    "testType" public."TestType" NOT NULL,
    "difficultyLevel" integer DEFAULT 5 NOT NULL,
    "failureCount" integer DEFAULT 0 NOT NULL,
    "attemptCount" integer DEFAULT 0 NOT NULL,
    "successRate" double precision DEFAULT 0 NOT NULL,
    "averageScore" double precision DEFAULT 0 NOT NULL,
    "lastFailedAt" timestamp(3) without time zone,
    priority integer DEFAULT 1 NOT NULL,
    recommendation text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.weakness_analysis OWNER TO postgres;

--
-- Name: weakness_analysis_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.weakness_analysis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.weakness_analysis_id_seq OWNER TO postgres;

--
-- Name: weakness_analysis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.weakness_analysis_id_seq OWNED BY public.weakness_analysis.id;


--
-- Name: AIWritingAssessment id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AIWritingAssessment" ALTER COLUMN id SET DEFAULT nextval('public."AIWritingAssessment_id_seq"'::regclass);


--
-- Name: AdminTask id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminTask" ALTER COLUMN id SET DEFAULT nextval('public."AdminTask_id_seq"'::regclass);


--
-- Name: AiChatSession id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AiChatSession" ALTER COLUMN id SET DEFAULT nextval('public."AiChatSession_id_seq"'::regclass);


--
-- Name: Device id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Device" ALTER COLUMN id SET DEFAULT nextval('public."Device_id_seq"'::regclass);


--
-- Name: Follow id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Follow" ALTER COLUMN id SET DEFAULT nextval('public."Follow_id_seq"'::regclass);


--
-- Name: GroupApplication id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication" ALTER COLUMN id SET DEFAULT nextval('public."GroupApplication_id_seq"'::regclass);


--
-- Name: Inquiry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inquiry" ALTER COLUMN id SET DEFAULT nextval('public."Inquiry_id_seq"'::regclass);


--
-- Name: Lesson id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson" ALTER COLUMN id SET DEFAULT nextval('public."Lesson_id_seq"'::regclass);


--
-- Name: LoginLog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginLog" ALTER COLUMN id SET DEFAULT nextval('public."LoginLog_id_seq"'::regclass);


--
-- Name: Material id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Material" ALTER COLUMN id SET DEFAULT nextval('public."Material_id_seq"'::regclass);


--
-- Name: MockResult id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockResult" ALTER COLUMN id SET DEFAULT nextval('public."MockResult_id_seq"'::regclass);


--
-- Name: MockSession id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockSession" ALTER COLUMN id SET DEFAULT nextval('public."MockSession_id_seq"'::regclass);


--
-- Name: Notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification" ALTER COLUMN id SET DEFAULT nextval('public."Notification_id_seq"'::regclass);


--
-- Name: PartnerRequest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartnerRequest" ALTER COLUMN id SET DEFAULT nextval('public."PartnerRequest_id_seq"'::regclass);


--
-- Name: PasswordResetToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken" ALTER COLUMN id SET DEFAULT nextval('public."PasswordResetToken_id_seq"'::regclass);


--
-- Name: PracticeTest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTest" ALTER COLUMN id SET DEFAULT nextval('public."PracticeTest_id_seq"'::regclass);


--
-- Name: PracticeTestResult id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTestResult" ALTER COLUMN id SET DEFAULT nextval('public."PracticeTestResult_id_seq"'::regclass);


--
-- Name: ProgressSnapshot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProgressSnapshot" ALTER COLUMN id SET DEFAULT nextval('public."ProgressSnapshot_id_seq"'::regclass);


--
-- Name: Question id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question" ALTER COLUMN id SET DEFAULT nextval('public."Question_id_seq"'::regclass);


--
-- Name: Report id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report" ALTER COLUMN id SET DEFAULT nextval('public."Report_id_seq"'::regclass);


--
-- Name: StrategicGoal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StrategicGoal" ALTER COLUMN id SET DEFAULT nextval('public."StrategicGoal_id_seq"'::regclass);


--
-- Name: StudyGroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyGroup" ALTER COLUMN id SET DEFAULT nextval('public."StudyGroup_id_seq"'::regclass);


--
-- Name: StudyStreak id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyStreak" ALTER COLUMN id SET DEFAULT nextval('public."StudyStreak_id_seq"'::regclass);


--
-- Name: TestUnlock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TestUnlock" ALTER COLUMN id SET DEFAULT nextval('public."TestUnlock_id_seq"'::regclass);


--
-- Name: TypingResult id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TypingResult" ALTER COLUMN id SET DEFAULT nextval('public."TypingResult_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: VerificationCode id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VerificationCode" ALTER COLUMN id SET DEFAULT nextval('public."VerificationCode_id_seq"'::regclass);


--
-- Name: WeeklyProgress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WeeklyProgress" ALTER COLUMN id SET DEFAULT nextval('public."WeeklyProgress_id_seq"'::regclass);


--
-- Name: centres id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centres ALTER COLUMN id SET DEFAULT nextval('public.centres_id_seq'::regclass);


--
-- Name: daily_study_logs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_study_logs ALTER COLUMN id SET DEFAULT nextval('public.daily_study_logs_id_seq'::regclass);


--
-- Name: leaderboard_entries id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_entries ALTER COLUMN id SET DEFAULT nextval('public.leaderboard_entries_id_seq'::regclass);


--
-- Name: leaderboards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboards ALTER COLUMN id SET DEFAULT nextval('public.leaderboards_id_seq'::regclass);


--
-- Name: skill_statistics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_statistics ALTER COLUMN id SET DEFAULT nextval('public.skill_statistics_id_seq'::regclass);


--
-- Name: test_attempts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_attempts ALTER COLUMN id SET DEFAULT nextval('public.test_attempts_id_seq'::regclass);


--
-- Name: user_study_streaks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_study_streaks ALTER COLUMN id SET DEFAULT nextval('public.user_study_streaks_id_seq'::regclass);


--
-- Name: weakness_analysis id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_analysis ALTER COLUMN id SET DEFAULT nextval('public.weakness_analysis_id_seq'::regclass);


--
-- Data for Name: AIWritingAssessment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AIWritingAssessment" (id, "userId", "writingText", "taskType", assessment, "overallBand", "createdAt", "updatedAt") FROM stdin;
1	8	There is a fact that education has three essential pillar  consisting the ability of read , write and mathemathical skilss, while some people belive that computer is a forth practical one for childeren. I absolutely agree with this forthside vision as I discuss in following  essay. \n\nIn the last decades technology have grown impresively and education is one of the most significant field which is affected by. As every one knows, computers are the pitval device in developed world of technology. Therefor there is no way out to add computational skills to fundamental elements of literacy in addition to their traditional ones. For example, in some especial situation like disease pandemic which restricted in-person education that actually have happened in our reall world recently, the only way to teach to the childeren is online-classes, hence in the case of lack of ability to use computers, schoolchildren can lose the lessons. \n\nOn the other hand, in modern world, daily activities rely on computers and their dependences are get biger and bolder day by day. For example, without comutational skills and awarness of softwares and practical application such as banking or ticket-booking ones, you can not manage your daily requirements  and alwayes have to ask other wich can be harmful and untrustable in many cases. On this base, it is clear that this experty is the unsepretable part of basic education and literacy these days. \n\nTo conclude, because of bold and prominant  impact of having sufficient knowledge and practicable abillity to use computers in education and other daily life tasks I completely agree to add this skill to the school educational curriculum.	Task2	{"strengths": ["Main points covered", "Some use of transitional phrases"], "weaknesses": ["Limited vocabulary", "Grammar errors", "Organization issues"], "overallBand": "6.25", "improvements": ["Practice vocabulary range", "Review verb tense and clause structure", "Work on organization and coherence"], "lexicalRange": {"band": 6, "score": "6.0", "feedback": "The writer uses some basic vocabulary, but there is a limited range of words and phrases. There are also some errors in word choice, such as 'forthside vision', 'pitval device', and 'reall world'."}, "estimatedScore": "5.5-6.5", "taskFulfillment": {"band": 6, "score": "6.0", "feedback": "Main points are covered, but some supporting details and organization are missing. The essay could benefit from a clearer introduction and conclusion."}, "overallBandRounded": 6, "grammaticalAccuracy": {"band": 5.5, "score": "5.5", "feedback": "The writer makes several grammatical errors, including verb tense inconsistencies, incorrect use of articles, and poor clause structure. For example, 'As every one knows' should be 'As everyone knows', and 'For example, in some especial situation' should be 'For example, in some specific situations'."}, "coherenceAndCohesion": {"band": 6.5, "score": "6.5", "feedback": "The writer uses some transitional phrases and linking words, but the text could be more cohesive. There are some abrupt changes in topics and ideas."}}	6.25	2026-04-21 12:33:24.629	2026-04-21 12:33:24.629
2	8	There is a fact that education has three essential pillar  consisting the ability of read , write and mathemathical skilss, while some people belive that computer is a forth practical one for childeren. I absolutely agree with this forthside vision as I discuss in following  essay. \n\nIn the last decades technology have grown impresively and education is one of the most significant field which is affected by. As every one knows, computers are the pitval device in developed world of technology. Therefor there is no way out to add computational skills to fundamental elements of literacy in addition to their traditional ones. For example, in some especial situation like disease pandemic which restricted in-person education that actually have happened in our reall world recently, the only way to teach to the childeren is online-classes, hence in the case of lack of ability to use computers, schoolchildren can lose the lessons. \n\nOn the other hand, in modern world, daily activities rely on computers and their dependences are get biger and bolder day by day. For example, without comutational skills and awarness of softwares and practical application such as banking or ticket-booking ones, you can not manage your daily requirements  and alwayes have to ask other wich can be harmful and untrustable in many cases. On this base, it is clear that this experty is the unsepretable part of basic education and literacy these days. \n\nTo conclude, because of bold and prominant  impact of having sufficient knowledge and practicable abillity to use computers in education and other daily life tasks I completely agree to add this skill to the school educational curriculum.	Task2	{"strengths": ["Clear main points", "Good use of basic vocabulary", "Logical flow"], "weaknesses": ["Limited vocabulary range", "Frequent grammatical errors", "Lack of cohesive linking between paragraphs"], "overallBand": "6.0", "improvements": ["Practice using a wider range of vocabulary", "Review grammar rules, particularly verb tenses and subject-verb agreement", "Work on creating a clear thesis statement and cohesive linking between paragraphs"], "lexicalRange": {"band": 6, "score": "6.0", "feedback": "Limited range of vocabulary, with some basic structures and expressions used repeatedly. There are also some errors in word choice, such as 'pitval device' instead of 'pivot device'."}, "estimatedScore": "5.5-6.5", "taskFulfillment": {"band": 6.5, "score": "6.5", "feedback": "Clear main points, but some minor details missing. The essay lacks a clear thesis statement and the introduction does not provide a strong opening."}, "overallBandRounded": 6, "grammaticalAccuracy": {"band": 5.5, "score": "5.5", "feedback": "Frequent errors in grammar, including verb tense inconsistencies, subject-verb agreement issues, and incorrect use of prepositions. For example, 'consisting the ability of read' should be 'consisting the abilities of reading' and 'forthside vision' is not a common phrase."}, "coherenceAndCohesion": {"band": 6, "score": "6.0", "feedback": "Good use of basic discourse markers, but the essay lacks a cohesive linking between paragraphs and ideas. Transitions between ideas could be smoother."}}	6	2026-04-21 12:43:10.362	2026-04-21 12:43:10.362
3	8	The grass will now be reintroduced to the British countryside. As a part of the Species Recovery Project, the organisation English Nature will re-introduce interrupted brome into the agricultural landscape, provided willing farmers are found. Alas, the grass is neither beautiful not practical. it is undoubtedly a weed, a weed that nobody cares for these days. The brome wax probably never widespread enough to annoy farmers and today, no one would appreciate its productivity or nutritious qualities. As a grass, it leaves a lot to be desited by agriculturalists.\n\nSmith’s research has attempted to answer the question of where the grass came from. His research points to mutations from other weedy grasses as the most likely source. So close is the relationship that interrupted brome was originally deemed to be a mere variety of soil brome by the great Victorian taxonomist Professor Hackel. A botanist from the 19th century, Druce. had taken notes on the grass and convinced his peers that the grass deserved its own status as a species. Despite Druce growing up in poverty and his self-taught profession, he became the leading botanist of his time.\n\nWhere the grass came from may be clear, but the timing of its birth may be tougher to find out. A clue lies in its penchant for growing as a weed in fields shared with a fodder crop, in particular nitrogen-fixing legumes such as sainfoin, lucerne or clover. According to agricultural historian Joan Thirsk. the humble sainfoin and its company were first noticed in Britain in the early 17th century. Seeds brought in from the Continent were sown in pastures to feed horses and other livestock. However, back then, only a few enthusiastic gentlemen were willing to use the new crops for their prized horses.\n\nNot before too long though, the need to feed the parliamentary armies in Scotland, England and behind was more pressing than ever. farmers were forced to produce more bread, cheese and beer. And by 1650 the legumes were increasingly introduced into arable rotations, to serve as green nature to boost grain yields. A bestseller of its day, Nathaniel Fiennes's Sainfoin Improved, published in 1671, helped to spread the word. With the advent of sainfoin, clover and lucerne. Britain's very own rogue grass had suddenly at rivet.	Task2	{"strengths": ["Clear structure", "Good vocabulary", "Logical flow", "Effective use of transitional phrases"], "weaknesses": ["Some grammatical errors", "Could vary sentence structure more", "Minor errors in word choice"], "overallBand": "7.25", "improvements": ["Practice complex sentence structures", "Review prepositions", "Vary sentence structure to improve flow"], "lexicalRange": {"band": 8, "score": "8.0", "feedback": "Good range of vocabulary, with some notable examples of sophisticated language, such as 'Species Recovery Project', 'botanist from the 19th century', and 'arable rotations'. However, there are a few instances of repetition and some minor errors in word choice (e.g., 'it leaves a lot to be desited' instead of 'desired')."}, "estimatedScore": "7.0-7.5", "taskFulfillment": {"band": 7, "score": "7.0", "feedback": "Clear main points, but some minor details missing. The writer has successfully addressed the topic, but there are a few instances where additional information would strengthen the argument."}, "overallBandRounded": 7, "grammaticalAccuracy": {"band": 6.5, "score": "6.5", "feedback": "Generally accurate, with some complex structures used effectively. However, there are a few errors, such as subject-verb agreement ('Alas, the grass is neither beautiful not practical') and some minor punctuation issues."}, "coherenceAndCohesion": {"band": 7, "score": "7.0", "feedback": "Good use of transitional phrases and logical flow, although there are some areas where the writer could link ideas more explicitly."}}	7.25	2026-04-21 12:44:23.277	2026-04-21 12:44:23.277
4	8	What is Lorem Ipsum?\nLorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.	Task2	{"strengths": [], "weaknesses": ["Lack of understanding of the task", "Poor vocabulary", "Numerous grammatical errors"], "overallBand": "0.5", "improvements": ["Read and understand the task carefully", "Practice writing original responses", "Review and practice grammar rules"], "lexicalRange": {"band": 0, "score": "0.0", "feedback": "The text uses very limited vocabulary, and it seems to be a copy-pasted passage rather than an original response. There is no demonstration of control over a range of vocabulary."}, "estimatedScore": "0.0-1.0", "taskFulfillment": {"band": 3, "score": "3.0", "feedback": "Lacks clear response to the task, fails to address the question. Note that the text appears to be a Lorem Ipsum passage rather than a response to the task. It's essential to provide a clear and concise answer to the question."}, "overallBandRounded": 1, "grammaticalAccuracy": {"band": 0, "score": "0.0", "feedback": "The text contains numerous grammatical errors, poor sentence structure, and lack of control over complex structures. It's essential to review and practice grammar rules to improve writing accuracy."}, "coherenceAndCohesion": {"band": 0, "score": "0.0", "feedback": "There is no logical flow or connection between ideas. The text appears to be a random passage rather than a response to the task. Discourse markers are not used effectively."}}	0.5	2026-04-21 12:45:20.766	2026-04-21 12:45:20.766
5	8	The two pie charts illustrate how the ages of UK tourists who visited Spain in the years 1983 and 2003.\n\nOverall, while people aged 34 to 54 made up the largest group in both years, their proportion showed a downward trend by 2003. Meanwhile, the percentage of older visitors, especially those aged 55 and above, increased noticeably. The age distribution also became more balanced over time.\n\nIn 1983, exactly half of all UK visitors to Spain were aged 34 to 54. The second largest group was those aged 25 to 34, accounting for 20%, followed by the 55+ group at 16%. Young individuals aged 0 to 15 and 16 to 24 made up 10% and 4%, respectively.\n\nBy 2003, the percentage of visitors aged 34 to 54 had dropped to 35%, while the 55+ group had risen sharply to 26%, becoming the second largest group. Similarly, the proportions of children and young adults increased slightly to 12% and 15%, respectively. In contrast, the 25 to 34 age group fell considerably to 12%.	Task1	{"strengths": ["Clear structure", "Good vocabulary", "Logical flow"], "weaknesses": ["Some grammatical errors", "Could vary sentence structure more", "Limited explanation and interpretation of data"], "overallBand": "6.75", "improvements": ["Practice complex sentence structures", "Review prepositions and verb forms", "Develop more nuanced analysis of the data"], "lexicalRange": {"band": 7, "score": "7.0", "feedback": "The student has used a good range of vocabulary, including words like 'illustrate,' 'trend,' 'distribution,' and 'increased.' However, there are some minor errors, such as using the phrase 'especially those aged 55 and above' instead of a more formal term, like 'those aged 55 or older.' Additionally, some of the vocabulary is a bit basic, such as 'young individuals' and 'children and young adults.'"}, "estimatedScore": "6.5-7.0", "taskFulfillment": {"band": 7, "score": "7.0", "feedback": "The student has clearly addressed the task, presenting the data from the pie charts and discussing the changes over time. However, some minor details are missing, such as explaining the relevance of the data or considering alternative interpretations. For example, the student could have discussed the potential reasons behind the downward trend in the 34-54 age group or the increase in the 55+ age group."}, "overallBandRounded": 7, "grammaticalAccuracy": {"band": 6.5, "score": "6.5", "feedback": "The student has generally accurate grammar, but there are some errors, such as 'The second largest group was those aged 25 to 34, accounting for 20%' (missing verb) and 'Similarly, the proportions of children and young adults increased slightly to 12% and 15%, respectively' (inconsistent verb form). Additionally, the student could have varied sentence structure more, as many of the sentences are simple or compound."}, "coherenceAndCohesion": {"band": 7, "score": "7.0", "feedback": "The student has used good discourse markers, such as 'meanwhile' and 'similarly,' to link ideas and create a logical flow. However, there are some minor issues with connecting ideas, as seen in the transition from discussing the 1983 data to the 2003 data. For instance, the student could have used a more explicit transition phrase, such as 'In contrast to the previous year,' to create a clearer connection between the two paragraphs."}}	6.75	2026-04-21 12:54:01.962	2026-04-21 12:54:01.962
\.


--
-- Data for Name: AdminTask; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AdminTask" (id, "adminId", title, notes, label, priority, "isDone", "doneAt", "assignedDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AiChatSession; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AiChatSession" (id, "userId", topic, "messageCount", "createdAt", "updatedAt", history, category, question, response) FROM stdin;
1	8	General	0	2026-04-20 18:47:00.007	2026-04-20 18:47:00.007	\N	GENERAL_MENTORING	hello	Hello. How are you doing today? You've been working hard on IELTS, and it's great that you're seeking more guidance. What specific areas of the test are you feeling a bit uncertain about? Is it writing, speaking, reading, or listening?
2	8	General	0	2026-04-20 18:47:13.754	2026-04-20 18:47:13.754	\N	GENERAL_MENTORING	what is your name?	Nice to meet you. My name is Emily, and I'm your IELTS mentor. I'll be supporting you throughout your preparation journey. Please feel free to share your concerns, questions, or any areas you'd like to improve.\n\nNow, let's get started. You mentioned you're looking for advice on your IELTS preparation. Can you tell me a bit more about where you're currently at? What do you feel are your strengths and weaknesses in the IELTS test, and what specific areas would you like to focus on during our sessions?
3	8	General	0	2026-04-20 18:47:38.949	2026-04-20 18:47:38.949	\N	GENERAL_MENTORING	check what im strugling with 	Don't worry, it's completely normal to feel unsure about your IELTS performance, especially when you're just starting out or have limited data. Can you tell me a bit more about what you're struggling with? Is it writing, speaking, reading, listening, or a combination of these?\n\nFrom what you mentioned, I'm going to take a guess that you might be feeling a bit uncertain about how to approach the test, or perhaps there's a particular area that you find challenging. Am I right?\n\nLet's break it down together, and I'll do my best to offer you some practical advice and guidance. Remember, we're not aiming for perfection here; we're working towards incremental improvements that will help you feel more confident and prepared for the test.\n\nSo, what's been the biggest challenge for you so far? Has it been a specific question type, a particular topic, or something else entirely?
4	8	General	0	2026-04-20 19:03:57.512	2026-04-20 19:03:57.512	\N	GENERAL_MENTORING	hello	Hello! It's great to see you again. I understand you have some questions about the IELTS exam. Since we don't have much data on your performance history, let's start with a general overview of the exam.\n\nCan you tell me a bit more about what you're struggling with? Are you having trouble with writing, speaking, reading, or listening? Or is it a particular aspect within those sections that's giving you trouble?\n\nAlso, what's your current goal for the IELTS exam? Are you aiming for a specific band score or just looking to improve in general?
5	8	General	0	2026-04-20 19:19:29.549	2026-04-20 19:19:29.549	\N	GENERAL_MENTORING	hello	Hello! It's great to see you again. How's your IELTS preparation going? I know you've been working hard, but I'd love to hear about your progress and get an idea of what challenges you're facing.\n\nPlease feel free to share your test history, if you have any, and your concerns or areas where you'd like to improve. We can discuss your weak points and create a plan tailored to your needs.\n\nAre you looking for tips on writing, speaking, reading, or listening?
6	8	General	0	2026-04-21 03:20:40.443	2026-04-21 03:20:40.443	\N	GENERAL_MENTORING	Hello	Hello there. It's great to see you again. What can I help you with today? Do you have questions about writing, speaking, reading, or listening?
7	8	General	0	2026-04-21 05:37:36.986	2026-04-21 05:37:36.986	\N	GENERAL_MENTORING	hello	Hello! I'm glad you came to see me today. I don't have any previous information about your IELTS performance, but let's start fresh. What area of IELTS are you concerned about? Is it writing, speaking, reading, or listening?
8	8	General	0	2026-04-21 06:35:05.554	2026-04-21 06:35:05.554	\N	GENERAL_MENTORING	what is my name?	I'm happy to help you with your IELTS questions, but it seems like we just started, and you haven't shared much about your performance history or specific areas of concern. Let's start fresh and get to know each other.\n\nMy name is Emily, and I'll be your IELTS mentor. I'm looking forward to helping you achieve your IELTS goals.\n\nNow, tell me a bit about yourself and what you're hoping to achieve in your IELTS exam. What's your current level of English proficiency, and have you taken any IELTS practice tests or exams before?
9	8	General	0	2026-04-21 06:35:40.47	2026-04-21 06:35:40.47	\N	GENERAL_MENTORING	No i have not taken any exam	Don't worry, we can start building your skills from scratch. Since we don't have any data on your past performance, let's focus on the essential areas to improve.\n\nFirstly, let's break down the IELTS exam into its four components: Writing, Speaking, Reading, and Listening. Each section has its unique requirements, but I'll provide you with a general overview.\n\nFor Writing, you'll have two tasks: Task 1, where you'll summarize a graph or chart, and Task 2, where you'll write an essay on a given topic. You'll need to demonstrate a good range of vocabulary, grammatical accuracy, and coherence in your writing. To get a Band 6 or higher, you'll need to show evidence of good writing skills, using a variety of vocabulary and structures, and demonstrating an ability to support your arguments with relevant examples (IELTS Band Descriptors).\n\nFor Speaking, you'll have a face-to-face conversation with an examiner, and it's divided into three sections: Introduction, Discussion, and Speaking about a Picture. You'll need to be able to express your opinions, ideas, and experiences in a clear and coherent manner. Remember, the examiner wants to see evidence of good communication skills, the ability to respond to complex questions and topics, and to demonstrate a range of vocabulary and pronunciation (IELTS Band Descriptors).\n\nFor Reading, you'll need to be able to comprehend a variety of texts, including academic passages, advertisements, and letters. You'll need to demonstrate an ability to identify the main idea, support your answers with relevant information, and recognize the author's tone and purpose.\n\nFor Listening, you'll need to be able to understand a range of spoken English, including conversations, lectures, and interviews. You'll need to be able to identify the main idea, recognize the speaker's attitude and purpose, and demonstrate an understanding of the relationships between ideas.\n\nNow, let's focus on building your skills incrementally. I recommend starting with the basics, such as vocabulary building, grammar practice, and listening and reading comprehension exercises. You can use online resources such as Khan Academy, IELTS podcasts, and the official IELTS website to practice.\n\nFor vocabulary building, I suggest you start by learning common IELTS topics and phrases. You can use flashcards or apps like Quizlet to create your own vocabulary lists. Set aside 15-20 minutes each day to practice vocabulary and grammar.\n\nFor listening and reading comprehension, start with short exercises and gradually increase the length and difficulty. Practice with audio and video recordings, podcasts, and online articles.\n\nFor writing and speaking, practice with sample questions and tasks. Focus on grammar, vocabulary, and coherence. Try to write essays or responses to sample questions, and record yourself speaking to evaluate your pronunciation and fluency.\n\nRemember, the key to improving your IELTS skills is consistency and practice. Set realistic goals, such as practicing for 15-20 minutes each day, and review your progress regularly. Don't worry if you make mistakes – it's all part of the learning process.\n\nLet's set a goal to practice for 15 minutes each day for the next week. We can review your progress and adjust our plan as needed. Sound good?
10	8	General	0	2026-04-21 06:36:00.64	2026-04-21 06:36:00.64	\N	GENERAL_MENTORING	Do you speak uzbek?	I'm happy to chat with you, but I'm afraid I don't speak Uzbek. As your IELTS mentor, our main focus is on preparing you for the English language proficiency test. \n\nHowever, I'd be happy to help you with any questions or concerns you have about IELTS. What's been going on with your studies so far? Have you had a chance to take any practice tests or receive feedback on your writing, speaking, reading, and listening skills?\n\nLet's start with where you are now and see how we can work together to improve your IELTS scores. What are your goals, and what areas do you feel need the most attention?
11	8	General	0	2026-04-21 06:37:50.714	2026-04-21 06:37:50.714	\N	GENERAL_MENTORING	Yes it would be big help	I'm more than happy to help you out. It sounds like you're looking for some guidance on IELTS, especially in areas where you're feeling a bit uncertain. \n\nTo start off, can you tell me a bit about your background and experience with the IELTS test? What score do you need to achieve, and how many times have you taken the test? This will give me a better idea of your strengths and weaknesses.\n\nAlso, are there any specific areas of the test that are giving you trouble? Is it the writing, speaking, reading, or listening section? The more information you can share, the more tailored my advice can be.\n\nAnd don't worry, we'll take things one step at a time. I'm here to support you every step of the way, and we'll work together to create a study plan that suits your needs and goals.\n\nSo, what's been going through your mind, and where do you feel you could use some guidance?
12	8	General	0	2026-04-21 06:37:51.228	2026-04-21 06:37:51.228	\N	GENERAL_MENTORING	Yes it would be big help	I'm happy to help you with IELTS. To get started, can you tell me a bit more about what areas of the test you're struggling with? Is it writing, speaking, reading, or listening?\n\nAlso, if you could share some of your previous test scores or feedback you've received, that would be really helpful. We can use that to identify areas where you need improvement.\n\nAssuming we don't have much data, let's focus on general strategies that can help you improve in all areas.\n\nFor writing, one of the most common mistakes IELTS test-takers make is rushing through the task and not spending enough time on each question. Remember, you have 60 minutes for Task 1 and 80 minutes for Task 2. Make sure to allocate your time wisely and leave enough time to review your work.\n\nIn terms of content, aim for a clear and concise introduction, a well-structured body with supporting evidence, and a logical conclusion. For example, in Task 2, you might write about the advantages and disadvantages of a particular issue. Make sure to give equal weight to both sides and use transition words to connect your ideas.\n\nFor speaking, practice is key. I recommend you record yourself speaking on various topics, such as your hobbies, education, or family. Listen back to the recordings and identify areas where you can improve, such as pronunciation, vocabulary, and fluency.\n\nWhen it comes to reading and listening, practice with sample questions and recordings from IELTS practice materials. Focus on understanding the main ideas and supporting details. In reading, aim to read the questions first and then skim the text to answer them. For listening, practice transcribing what you hear and then check your answers.\n\nIn terms of study strategies, I recommend setting aside dedicated time to practice each week. Break your study sessions into manageable chunks, such as 30 minutes of writing practice followed by 30 minutes of reading practice.\n\nDon't try to cram all your studying into one or two marathon sessions. Instead, aim for consistent progress over time. Set achievable targets, such as improving your writing score by one band over the next two months.\n\nRemember, IELTS is a test of your English language skills, but it's also a test of your ability to manage your time and stay focused under pressure. With consistent practice and dedication, you can improve your scores and achieve your goals.\n\nHow does that sound? Is there a specific area you'd like to focus on first?
13	8	General	0	2026-04-22 03:08:07.912	2026-04-22 03:08:07.912	\N	GENERAL_MENTORING	Hello	Hello. How can I help you today? You mentioned you'd like to discuss IELTS writing, speaking, reading, or listening. Can you tell me a bit more about your situation and what you're struggling with or hoping to improve?\n\n(By the way, I've taken a glance at your previous test results, but I want to emphasize that we can still work with limited data and focus on areas that need improvement.)
14	8	General	0	2026-04-22 03:08:08.08	2026-04-22 03:08:08.08	\N	GENERAL_MENTORING	Hello	Hello! How are you doing today? I see you're eager to improve your IELTS scores. I'd be happy to help you with that. What specific area of the exam are you struggling with or would like to focus on? Is it writing, speaking, reading, or listening?\n\nWe don't have much data on your performance history, so we'll start fresh. But feel free to share any previous attempts or scores you might have, even if it's just a rough idea of where you think you are.\n\nAlso, what's your goal for the IELTS exam? Are you aiming for a specific band score or university admission? This will help me tailor my advice to your needs.\n\nLet's work together to identify your strengths and weaknesses, and create a plan to help you improve incrementally. Sound good?
15	8	General	0	2026-04-22 04:57:33.226	2026-04-22 04:57:33.226	\N	GENERAL_MENTORING	hello	Hello again. How can I help you today? You've been working on your IELTS prep, but I understand you're looking for some specific guidance on certain areas. Is there a particular section, such as writing, speaking, reading, or listening, that you're struggling with or would like some advice on?\n\nPlease feel free to share your performance history, and we can tailor our conversation to address any weak areas you may have identified.
16	8	General	0	2026-04-22 04:57:34.075	2026-04-22 04:57:34.075	\N	GENERAL_MENTORING	hello	Hello there, how are you? I see you're here to discuss your IELTS preparations. I'd love to help. Since I don't have much information about your previous attempts or performance history, let's start with a general overview. Can you tell me a bit about your goals and what areas of the IELTS you're struggling with the most? Are you looking to improve your writing, speaking, reading, or listening skills?\n\nAlso, have you taken the IELTS before, or is this your first time attempting it? This will help me provide you with more tailored advice and guidance.\n\n(By the way, don't worry if you feel unsure about your preparation. We'll work together to break down your goals into manageable targets, and I'll provide you with practical tips and strategies to achieve them.)
17	8	General	0	2026-04-22 07:59:46.003	2026-04-22 07:59:46.003	\N	GENERAL_MENTORING	hello	Hello! It's great to see you again. How have you been preparing for the IELTS? Do you have any specific concerns or areas where you'd like some guidance?\n\nSince we don't have a lot of data to go on, let's start with a general overview. What type of task are you struggling with the most - is it writing, speaking, reading, or listening?
18	8	General	0	2026-04-22 07:59:46.005	2026-04-22 07:59:46.005	\N	GENERAL_MENTORING	hello	Hello! I'm glad you came to see me. How's it going so far in your IELTS preparation? You mentioned you have a question about IELTS, can you tell me a bit more about what's on your mind?\n\n(Note: I'll be considering that limited data is available about their performance history, so let's start from scratch and see where we can go from here.)
19	8	General	0	2026-04-23 08:41:51.722	2026-04-23 08:41:51.722	\N	GENERAL_MENTORING	hello	Hello! It's great to see you again. What's on your mind today? Is it writing, speaking, reading, or listening that's been giving you trouble? \n\nRemember, we've only had a chance to do a few mock tests together, but I think it's essential we focus on areas that need improvement. We can always build on your strengths later. \n\nWhat have you been practicing lately, and what do you think you need help with?
20	8	General	0	2026-04-23 08:41:51.813	2026-04-23 08:41:51.813	\N	GENERAL_MENTORING	hello	Hello! It's great to see you again. I've been looking over your IELTS practice tests, and I think I have a good sense of your strengths and weaknesses. How about we start with the area where you're feeling a bit uncertain? Is it writing, speaking, reading, or listening that you'd like to focus on first?\n\nAlso, just to confirm, you haven't taken a full IELTS test yet, right? We can work on developing a study plan tailored to your needs and goals.\n\nTo get started, can you tell me a bit more about your current practice? How have you been studying, and what do you feel is the most challenging part for you? This will help me provide more targeted advice and guidance.
\.


--
-- Data for Name: Device; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Device" (id, "userId", "deviceType", "deviceName", browser, os, "ipAddress", location, latitude, longitude, "userAgent", "isActive", "lastActiveAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Follow; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Follow" (id, "studentId", "teacherId", "createdAt") FROM stdin;
\.


--
-- Data for Name: GroupApplication; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupApplication" (id, "studentId", "groupId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Inquiry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Inquiry" (id, "centreId", "studentName", "studentEmail", message, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: Lesson; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Lesson" (id, title, "zoomLink", "startTime", status, "teacherId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: LoginLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoginLog" (id, "userId", "ipAddress", "deviceInfo", "userAgent", success, reason, "timestamp") FROM stdin;
\.


--
-- Data for Name: Material; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Material" (id, "fileName", "fileUrl", "fileType", "teacherId", "lessonId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MockResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MockResult" (id, "studentId", "sessionId", listening, reading, writing, speaking, overall, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MockSession; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MockSession" (id, "centreId", "dateTime", type, format, location, capacity, price, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, icon, message, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: PartnerRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PartnerRequest" (id, centre_name, ceo_name, email, phone, location, status, password, "createdAt") FROM stdin;
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordResetToken" (id, "userId", token, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: PracticeTest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PracticeTest" (id, title, "testType", "practiceMode", "focusArea", "durationMins", instructions, passage, "audioUrl", "isPublished", "isArchived", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PracticeTestResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PracticeTestResult" (id, "userId", "testId", "testIdentifier", "testCategory", "testSubcategory", "setNumber", score, "bandScore", "correctAnswers", "totalQuestions", "timeSpentSeconds", answers, "isCompleted", "isUnlocked", "completedAt", "aiAnalysis", "progressNote", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProgressSnapshot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProgressSnapshot" (id, "userId", "listeningAvg", "readingAvg", "writingAvg", "speakingAvg", "overallAvg", "estimatedBand", "targetBand", "testsCompleted", "currentStreak", "bestStreak", "weakAreas", "strongAreas", "isMakingProgress", "aiConclusion", recommendation, "snapshotDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Question" (id, "testId", "questionText", type, options, "correctAnswer", "orderIndex", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Report" (id, "studentId", "testId", "questionId", type, status, description, "resolvedById", "resolutionNote", "resolvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StrategicGoal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StrategicGoal" (id, title, priority, "column", "dueDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StudyGroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StudyGroup" (id, "centreId", "teacherId", name, level, schedule, "startDate", "endDate", capacity, status, description, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StudyStreak; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StudyStreak" (id, "userId", date, "isCompleted") FROM stdin;
1	8	2026-04-21	t
10	8	2026-04-22	t
\.


--
-- Data for Name: TestUnlock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TestUnlock" (id, "userId", category, subcategory, "maxUnlockedSet", "minScoreRequired", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TypingResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TypingResult" (id, "userId", wpm, accuracy, date, "durationMinutes", difficulty) FROM stdin;
1	8	48	100	2026-04-21 03:37:37.863	1	intermediate
2	8	50	97	2026-04-21 03:38:41.077	1	intermediate
3	8	49	100	2026-04-21 04:13:48.891	1	intermediate
4	8	51	99	2026-04-21 04:18:18.391	1	intermediate
5	8	49	100	2026-04-21 05:17:28.056	1	intermediate
6	8	59	100	2026-04-21 12:56:15.7	1	intermediate
7	8	48	98	2026-04-21 13:03:18.185	1	intermediate
8	8	43	79	2026-04-21 13:06:38.362	1	intermediate
9	8	60	100	2026-04-21 13:09:35.092	1	intermediate
10	8	48	100	2026-04-22 02:47:06.639	2	intermediate
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, full_name, name, email, username, password, country, phone, test_type, role, is_verified, "isVerified", is_onboarded, "isOnboarded", target_band, "targetBand", current_band, "currentBand", study_hours, tasks_done, "tasksDone", weekly_goal_percent, exam_date, "examDate", exam_date_text, target_band_range, study_commitment, referral_source, "isActive", "lastSeenAt", "isExamDateUnsure", "sourceOfExposure", "onboardingComplete", "centreId", "createdAt", "updatedAt") FROM stdin;
5	CEO Account	\N	ceo@ieltspractice.com	\N	$2b$10$3kdKpbMzfF5lPUFFOE7xJuoj1xMVx7eh/I51yDVJ8yDb9YJyDx9AS	Uzbekistan	\N	\N	CEO	t	f	f	f	8	8	9	5	0	0	0	0	\N	\N	\N	\N	\N	\N	t	\N	t	\N	f	\N	2026-04-14 04:29:40.551	2026-04-14 04:29:40.551
6	Admin Account	\N	admin@ieltspractice.com	\N	$2b$10$1YOsmB0uFh48ppHgMkXZVOJoEHaVdpqTAjp58cH6gBbiD6x7z6blm	Uzbekistan	\N	\N	ADMIN	t	f	f	f	8	8	8	5	0	0	0	0	\N	\N	\N	\N	\N	\N	t	\N	t	\N	f	\N	2026-04-14 04:29:40.563	2026-04-14 04:29:40.563
11	dsdsd	\N	need3164@gmail.com	need3164	$2b$12$6Z6lom6nVoqlOinXDfDOe.wgqm0SLAtpA0981aGwfSuhQgmrUSAmS	\N	\N	\N	STUDENT	f	f	f	f	8	8	5	5	0	0	0	0	\N	\N	\N	\N	\N	\N	t	\N	t	\N	f	\N	2026-04-23 14:28:20.793	2026-04-23 14:28:20.793
9	a	a	sdjsk@gmail.com	sdjsk	$2b$12$iWTH7OVKxLt3MbNVYyRpKOwCwGHKzpHDrtHBav3n5SDMciJ.7jpQ2	Uzbekistan		Academic	STUDENT	t	f	t	f	7.5	7.5	5	5	0	0	0	0	2026-07-18 00:00:00	2026-07-18 00:00:00	2026-07-18	\N	\N	\N	t	2026-04-14 08:15:21.889	f	Friend	t	\N	2026-04-14 04:39:22.95	2026-04-14 10:24:18.75
7	Ahrorbek Xalimov	Ahrorbek Xalimov	khalimovahrorbek@gmail.com	ahror	$2b$12$cs5ZKHrhoKRmm0gfKkrxWOpT.lOP11KLFJg76fUA6duMnOzo2U5Vy	Uzbekistan	\N	\N	STUDENT	t	f	f	f	8	8	5	5	0	0	0	0	\N	\N	\N	\N	\N	\N	t	2026-04-14 04:45:54.345	t	\N	f	\N	2026-04-14 04:29:40.993	2026-04-14 04:45:54.347
10	Xalimov Ahrorbek	\N	johnfellar@gmail.com	johnfellar	$2b$12$G5nLKTZA2N7g/OOErwJCO.nUhdsLl72Am/wWNWfQCfDLG8VYOLERy	\N	\N	\N	STUDENT	t	f	t	f	8	8	5	5	0	0	0	0	2026-07-09 00:00:00	\N	\N	\N	\N	\N	t	2026-04-20 10:06:49.747	f	Friend	t	\N	2026-04-20 10:06:33.225	2026-04-20 10:07:44.241
8	Moneycold1	Moneycold1	dsd@gmail.com	moneycold	$2b$12$wlMmDEc7wHh1WPPtLTdT6uP.1hyRd9sm6cuPsaHfxv4j7BYE0KMzy	Uzbekistan		Academic	STUDENT	t	f	t	f	8.5	8.5	5	5	0	0	0	0	2027-04-07 00:00:00	2027-04-07 00:00:00	2027-04-07	\N	\N	\N	t	2026-04-23 13:52:51.727	f	Friend	t	\N	2026-04-14 04:33:57.797	2026-04-23 13:52:51.729
\.


--
-- Data for Name: VerificationCode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VerificationCode" (id, email, code, "expiresAt", "createdAt") FROM stdin;
4	need3164@gmail.com	128026	2026-04-24 14:28:20.804	2026-04-23 14:28:20.806
\.


--
-- Data for Name: WeeklyProgress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WeeklyProgress" (id, "userId", "weekStartDate", "perfectScoresCount", "progressPercentage") FROM stdin;
\.


--
-- Data for Name: _Staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_Staff" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
d19def53-4306-41d4-a876-1f66f79f0bb9	dbf348fc780b35b9cfe2baa37d4eed4981e0e45a5f91e2dea047810ba381172d	2026-04-14 09:28:04.136235+05	20260413170304_init	\N	\N	2026-04-14 09:28:03.819479+05	1
45837a56-7386-4a7d-94ab-b4cdd7a23875	b288dfe9a4d543d59375b885ce3c0c7f95de9b7f9ffbafb46651efc8230b161f	2026-04-20 13:21:29.020619+05	20260305170643_init		\N	2026-04-20 13:21:29.020619+05	0
0a980010-3305-48fa-8ede-c450d62bc88a	1e378322931749eb7acba20dbb1d42d346c2866b38478c184c9f0df93d88c52f	\N	20260307144936_upgrade_ceo_mission_control	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260307144936_upgrade_ceo_mission_control\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "TaskLabel" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"TaskLabel\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1167), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260307144936_upgrade_ceo_mission_control"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260307144936_upgrade_ceo_mission_control"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-04-20 13:31:53.705176+05	2026-04-20 13:24:51.433421+05	0
b9808c81-2a47-491e-95f8-08a45a8b12a0	1e378322931749eb7acba20dbb1d42d346c2866b38478c184c9f0df93d88c52f	\N	20260307144936_upgrade_ceo_mission_control	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260307144936_upgrade_ceo_mission_control\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "TaskLabel" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"TaskLabel\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1167), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260307144936_upgrade_ceo_mission_control"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260307144936_upgrade_ceo_mission_control"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-04-20 13:34:08.46497+05	2026-04-20 13:32:05.62555+05	0
b68e4852-1350-4ff9-b68a-3b34d97b1e22	1e378322931749eb7acba20dbb1d42d346c2866b38478c184c9f0df93d88c52f	2026-04-20 13:34:08.46953+05	20260307144936_upgrade_ceo_mission_control		\N	2026-04-20 13:34:08.46953+05	0
0b859d63-b412-456f-a617-c2872b700efa	41443ebdbbbfd83bec5cc579476c7875ecaa367018cac250d3c1ea3fab7abe34	\N	20260308143915_overhaul_admin_v2	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260308143915_overhaul_admin_v2\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "TestType" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"TestType\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1167), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260308143915_overhaul_admin_v2"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260308143915_overhaul_admin_v2"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	\N	2026-04-20 13:34:26.925081+05	0
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcements (id, title, content, type, "isActive", "createdAt", "updatedAt", "createdBy") FROM stdin;
\.


--
-- Data for Name: centres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.centres (id, name, code, city, address, phone, website, "totalStudents", "activeStudents", rating, "isActive", "createdAt", "updatedAt", country, email, "managerId", latitude, longitude) FROM stdin;
1	British Council Tashkent	BC-TAS	Tashkent	107 Amir Temur Avenue	+998 71 1234567	https://britishcouncil.uz	0	0	4.8	t	2026-04-14 04:29:40.585	2026-04-14 04:29:40.585	Uzbekistan	\N	\N	41.3111	69.2406
2	IDP IELTS Tashkent	IDP-TAS-01	Tashkent	45 Oybek Street, Tashkent	+998 71 2000202	https://idp.uz	0	0	4.7	t	2026-04-14 04:29:40.596	2026-04-14 04:29:40.596	Uzbekistan	\N	\N	41.2995	69.2664
3	IELTS Zone Tashkent	IZ-TAS-01	Tashkent	Chilonzor 1, Tashkent	+998 90 1234567	https://ieltszone.uz	0	0	4.9	t	2026-04-14 04:29:40.608	2026-04-14 04:29:40.608	Uzbekistan	\N	\N	41.2827	69.2041
4	Innovative Centre Samarkand	INN-SAM	Samarkand	12 Registon Street	+998 66 1234567	https://innovative.uz	0	0	4.9	t	2026-04-14 04:29:40.619	2026-04-14 04:29:40.619	Uzbekistan	\N	\N	39.6542	66.9597
5	Education First Bukhara	EF-BUK-01	Bukhara	B. Naqshband Street, Bukhara	+998 65 1234567	https://efbukhara.uz	0	0	4.5	t	2026-04-14 04:29:40.63	2026-04-14 04:29:40.63	Uzbekistan	\N	\N	39.7747	64.4286
\.


--
-- Data for Name: daily_study_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.daily_study_logs (id, "userId", "studyDate", "testsCompleted", "timeSpentMinutes", "skillsPracticed", "createdAt") FROM stdin;
1	8	2026-04-21 19:00:00	1	0	\N	2026-04-22 05:40:17.269
\.


--
-- Data for Name: leaderboard_entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leaderboard_entries (id, "leaderboardId", "userId", rank, score, trend, "trendAmount", "userName", "userCountry", "userAvatar", "updatedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: leaderboards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.leaderboards (id, category, title, description, "isActive", "updatedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: live_session_participants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.live_session_participants (id, "sessionId", "userId", "joinedAt", "leftAt", role, "createdAt") FROM stdin;
\.


--
-- Data for Name: live_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.live_sessions (id, title, description, "teacherId", "sessionType", "startTime", "endTime", "maxParticipants", status, "isFeatured", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- Data for Name: skill_statistics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skill_statistics (id, "userId", skill, "totalAttempts", "completedAttempts", "averageScore", "bestScore", "worstScore", "totalTimeSpentSeconds", "averageTimeSpentSeconds", "improvementRate", "consistencyScore", "lastAttemptAt", "createdAt", "updatedAt") FROM stdin;
1	8	LISTENING	1	1	0	0	0	2	2	0	0	2026-04-22 05:40:17.241	2026-04-22 05:40:17.259	2026-04-22 05:40:17.259
\.


--
-- Data for Name: test_attempts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_attempts (id, "userId", "testType", "testId", "testName", "skillArea", score, "maxScore", "percentageScore", "timeSpentSeconds", status, "answersCorrect", "answersTotal", feedback, "completedAt", "createdAt", "updatedAt") FROM stdin;
1	8	LISTENING	Listening-Set1	Listening Test - Set 1	LISTENING_COMPREHENSION	0	9	\N	2	COMPLETED	0	40	\N	2026-04-22 05:40:17.241	2026-04-22 05:40:17.242	2026-04-22 05:40:17.242
\.


--
-- Data for Name: test_submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_submissions (id, "userId", "testId", "testType", answers, score, "bandScore", "timeSpent", "submittedAt", "gradedAt", feedback) FROM stdin;
\.


--
-- Data for Name: typing_practice_texts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.typing_practice_texts (id, title, content, difficulty, "wordCount", topics, "isActive", "createdAt", "updatedAt") FROM stdin;
cmny4g3ps0000j2w9w2sk8zcn	Architecture and Sustainability	The development of sustainable architecture has become increasingly vital in recent years. Architects are now focusing on creating buildings that minimize environmental impact through efficient use of energy, water, and materials. This involves incorporating renewable energy sources, such as solar panels and wind turbines, and utilizing recycled or locally sourced materials. Furthermore, sustainable design often includes features like green roofs and natural ventilation systems to reduce the need for artificial heating and cooling. As urbanization continues to rise, the integration of sustainability into architectural practices is essential for mitigating climate change and promoting a healthier, more resilient built environment for future generations.	intermediate	118	Academic,Environment,Architecture	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3ps0001j2w9zz15w5t8	Climate Change Solutions	Global warming represents one of the most pressing challenges facing humanity today. Addressing this complex issue requires a multi-faceted approach involving international cooperation, technological innovation, and individual action. One key strategy is the transition from fossil fuels to clean, renewable energy sources like wind, solar, and hydroelectric power. Additionally, reforestation and the protection of existing forests play a crucial role in absorbing carbon dioxide from the atmosphere. Governments can also implement policies such as carbon pricing and stricter emission standards for industries. Ultimately, a combination of large-scale systemic changes and everyday sustainable choices is necessary to reduce greenhouse gas emissions and protect our planet's future.	advanced	120	Environment,Science,Climate	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3ps0002j2w9sbnk0jum	The Importance of Biodiversity	Biodiversity is the variety of life on Earth, encompassing all species of plants, animals, and microorganisms, as well as the ecosystems they form. It provides essential services that support human life, including food production, water purification, and climate regulation. However, human activities such as habitat destruction, pollution, and overexploitation are leading to an unprecedented rate of species extinction. Protecting biodiversity is not only a moral imperative but also a practical necessity for maintaining the stability and productivity of our planet. Conservation efforts must focus on preserving natural habitats, restoring degraded ecosystems, and promoting sustainable management of natural resources to ensure that future generations can continue to benefit from the richness of life on Earth.	advanced	124	Biology,Environment,Nature	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3ps0003j2w9l5dtbhp0	Digital Transformation in Education	The landscape of education is undergoing a profound transformation driven by digital technology. Online learning platforms, interactive software, and mobile applications are providing students with unprecedented access to information and educational resources. This shift allows for more personalized learning experiences, as students can progress at their own pace and explore topics that interest them. Teachers are also using digital tools to enhance classroom instruction and facilitate collaboration among students. While digital transformation offers many benefits, it also presents challenges, such as the digital divide and the need for new pedagogical approaches. Ensuring that all students have equal access to technology and developing digital literacy skills are crucial for preparing them for success in the 21st century.	intermediate	130	Technology,Education,Digital	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3pt0004j2w97pqb5tqx	The History of the Olympic Games	The Olympic Games have a long and storied history, dating back to ancient Greece. The first recorded Olympic Games were held in 776 BC in Olympia, as a festival to honor the god Zeus. These ancient games featured various athletic competitions, including running, wrestling, and chariot racing. The modern Olympic Games were revived in 1896 by Pierre de Coubertin, who envisioned them as a way to promote international understanding and peace through sport. Today, the Olympics are a global event, bringing together thousands of athletes from around the world to compete in a wide range of summer and winter sports. The Games continue to inspire people with their message of excellence, friendship, and respect.	beginner	128	History,Sports,Culture	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3pt0005j2w984mqz3ma	The Benefits of Regular Exercise	Regular physical activity is one of the most important things you can do for your health. It can help you manage your weight, reduce your risk of chronic diseases such as heart disease and diabetes, and strengthen your bones and muscles. Exercise also has significant mental health benefits, including reducing stress, anxiety, and depression. Whether it's a brisk walk, a swim, or a yoga session, finding an activity you enjoy and making it a part of your daily routine can greatly improve your overall well-being. Aim for at least 150 minutes of moderate-intensity aerobic activity per week, along with muscle-strengthening activities on two or more days. The rewards of staying active are well worth the effort.	beginner	126	Health,Fitness,Lifestyle	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3pt0006j2w98e5aqcz7	Artificial Intelligence in Healthcare	Artificial Intelligence (AI) is revolutionizing the healthcare industry by enhancing diagnostic accuracy, personalizing treatment plans, and improving patient outcomes. AI algorithms can analyze vast amounts of medical data, including imaging and genomic information, to identify patterns that might be missed by human clinicians. This technology is being used to detect diseases like cancer at earlier stages and to develop more effective drugs and therapies. Furthermore, AI-powered virtual assistants and chatbots are providing patients with 24/7 support and personalized health advice. While AI offers immense potential, it also raises ethical concerns regarding data privacy and the role of human judgment in medical decision-making. As AI continues to evolve, its integration into healthcare must be carefully managed to ensure it benefits all patients.	advanced	132	Technology,Healthcare,AI	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3pt0007j2w9nnmwjws4	The Future of Space Exploration	Space exploration has entered a new era, with both government agencies and private companies working to reach new frontiers. Missions to Mars, the establishment of lunar bases, and the search for extraterrestrial life are among the ambitious goals of current and future space programs. Advances in rocket technology and robotics are making these missions more feasible and cost-effective. Additionally, space exploration has the potential to yield significant scientific discoveries and technological innovations that can benefit life on Earth. However, the challenges of long-duration space travel, including radiation exposure and resource management, remain significant. As we look to the stars, international collaboration and a shared vision for the peaceful use of space will be essential for the continued success of our journey into the cosmos.	intermediate	134	Science,Space,Future	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4gqeh0000j27pkwoz1b0m	Architecture and Sustainability	The development of sustainable architecture has become increasingly vital in recent years. Architects are now focusing on creating buildings that minimize environmental impact through efficient use of energy, water, and materials. This involves incorporating renewable energy sources, such as solar panels and wind turbines, and utilizing recycled or locally sourced materials. Furthermore, sustainable design often includes features like green roofs and natural ventilation systems to reduce the need for artificial heating and cooling. As urbanization continues to rise, the integration of sustainability into architectural practices is essential for mitigating climate change and promoting a healthier, more resilient built environment for future generations.	intermediate	118	Academic,Environment,Architecture	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0001j27pj3xm6eb2	Climate Change Solutions	Global warming represents one of the most pressing challenges facing humanity today. Addressing this complex issue requires a multi-faceted approach involving international cooperation, technological innovation, and individual action. One key strategy is the transition from fossil fuels to clean, renewable energy sources like wind, solar, and hydroelectric power. Additionally, reforestation and the protection of existing forests play a crucial role in absorbing carbon dioxide from the atmosphere. Governments can also implement policies such as carbon pricing and stricter emission standards for industries. Ultimately, a combination of large-scale systemic changes and everyday sustainable choices is necessary to reduce greenhouse gas emissions and protect our planet's future.	advanced	120	Environment,Science,Climate	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0002j27pp7351139	The Importance of Biodiversity	Biodiversity is the variety of life on Earth, encompassing all species of plants, animals, and microorganisms, as well as the ecosystems they form. It provides essential services that support human life, including food production, water purification, and climate regulation. However, human activities such as habitat destruction, pollution, and overexploitation are leading to an unprecedented rate of species extinction. Protecting biodiversity is not only a moral imperative but also a practical necessity for maintaining the stability and productivity of our planet. Conservation efforts must focus on preserving natural habitats, restoring degraded ecosystems, and promoting sustainable management of natural resources to ensure that future generations can continue to benefit from the richness of life on Earth.	advanced	124	Biology,Environment,Nature	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0003j27pe2t2t5gn	Digital Transformation in Education	The landscape of education is undergoing a profound transformation driven by digital technology. Online learning platforms, interactive software, and mobile applications are providing students with unprecedented access to information and educational resources. This shift allows for more personalized learning experiences, as students can progress at their own pace and explore topics that interest them. Teachers are also using digital tools to enhance classroom instruction and facilitate collaboration among students. While digital transformation offers many benefits, it also presents challenges, such as the digital divide and the need for new pedagogical approaches. Ensuring that all students have equal access to technology and developing digital literacy skills are crucial for preparing them for success in the 21st century.	intermediate	130	Technology,Education,Digital	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0004j27p9mxprgdb	The History of the Olympic Games	The Olympic Games have a long and storied history, dating back to ancient Greece. The first recorded Olympic Games were held in 776 BC in Olympia, as a festival to honor the god Zeus. These ancient games featured various athletic competitions, including running, wrestling, and chariot racing. The modern Olympic Games were revived in 1896 by Pierre de Coubertin, who envisioned them as a way to promote international understanding and peace through sport. Today, the Olympics are a global event, bringing together thousands of athletes from around the world to compete in a wide range of summer and winter sports. The Games continue to inspire people with their message of excellence, friendship, and respect.	beginner	128	History,Sports,Culture	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0005j27pnqm6wzmp	The Benefits of Regular Exercise	Regular physical activity is one of the most important things you can do for your health. It can help you manage your weight, reduce your risk of chronic diseases such as heart disease and diabetes, and strengthen your bones and muscles. Exercise also has significant mental health benefits, including reducing stress, anxiety, and depression. Whether it's a brisk walk, a swim, or a yoga session, finding an activity you enjoy and making it a part of your daily routine can greatly improve your overall well-being. Aim for at least 150 minutes of moderate-intensity aerobic activity per week, along with muscle-strengthening activities on two or more days. The rewards of staying active are well worth the effort.	beginner	126	Health,Fitness,Lifestyle	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0006j27p4wl9ax3y	Artificial Intelligence in Healthcare	Artificial Intelligence (AI) is revolutionizing the healthcare industry by enhancing diagnostic accuracy, personalizing treatment plans, and improving patient outcomes. AI algorithms can analyze vast amounts of medical data, including imaging and genomic information, to identify patterns that might be missed by human clinicians. This technology is being used to detect diseases like cancer at earlier stages and to develop more effective drugs and therapies. Furthermore, AI-powered virtual assistants and chatbots are providing patients with 24/7 support and personalized health advice. While AI offers immense potential, it also raises ethical concerns regarding data privacy and the role of human judgment in medical decision-making. As AI continues to evolve, its integration into healthcare must be carefully managed to ensure it benefits all patients.	advanced	132	Technology,Healthcare,AI	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0007j27pinheyc0t	The Future of Space Exploration	Space exploration has entered a new era, with both government agencies and private companies working to reach new frontiers. Missions to Mars, the establishment of lunar bases, and the search for extraterrestrial life are among the ambitious goals of current and future space programs. Advances in rocket technology and robotics are making these missions more feasible and cost-effective. Additionally, space exploration has the potential to yield significant scientific discoveries and technological innovations that can benefit life on Earth. However, the challenges of long-duration space travel, including radiation exposure and resource management, remain significant. As we look to the stars, international collaboration and a shared vision for the peaceful use of space will be essential for the continued success of our journey into the cosmos.	intermediate	134	Science,Space,Future	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4hboe0000j2qm2j4ahhzk	Architecture and Sustainability	The development of sustainable architecture has become increasingly vital in recent years. Architects are now focusing on creating buildings that minimize environmental impact through efficient use of energy, water, and materials. This involves incorporating renewable energy sources, such as solar panels and wind turbines, and utilizing recycled or locally sourced materials. Furthermore, sustainable design often includes features like green roofs and natural ventilation systems to reduce the need for artificial heating and cooling. As urbanization continues to rise, the integration of sustainability into architectural practices is essential for mitigating climate change and promoting a healthier, more resilient built environment for future generations.	intermediate	118	Academic,Environment,Architecture	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0001j2qme0jlzcct	Climate Change Solutions	Global warming represents one of the most pressing challenges facing humanity today. Addressing this complex issue requires a multi-faceted approach involving international cooperation, technological innovation, and individual action. One key strategy is the transition from fossil fuels to clean, renewable energy sources like wind, solar, and hydroelectric power. Additionally, reforestation and the protection of existing forests play a crucial role in absorbing carbon dioxide from the atmosphere. Governments can also implement policies such as carbon pricing and stricter emission standards for industries. Ultimately, a combination of large-scale systemic changes and everyday sustainable choices is necessary to reduce greenhouse gas emissions and protect our planet's future.	advanced	120	Environment,Science,Climate	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0002j2qm5a0f3fan	The Importance of Biodiversity	Biodiversity is the variety of life on Earth, encompassing all species of plants, animals, and microorganisms, as well as the ecosystems they form. It provides essential services that support human life, including food production, water purification, and climate regulation. However, human activities such as habitat destruction, pollution, and overexploitation are leading to an unprecedented rate of species extinction. Protecting biodiversity is not only a moral imperative but also a practical necessity for maintaining the stability and productivity of our planet. Conservation efforts must focus on preserving natural habitats, restoring degraded ecosystems, and promoting sustainable management of natural resources to ensure that future generations can continue to benefit from the richness of life on Earth.	advanced	124	Biology,Environment,Nature	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0003j2qm1o5y7yqc	Digital Transformation in Education	The landscape of education is undergoing a profound transformation driven by digital technology. Online learning platforms, interactive software, and mobile applications are providing students with unprecedented access to information and educational resources. This shift allows for more personalized learning experiences, as students can progress at their own pace and explore topics that interest them. Teachers are also using digital tools to enhance classroom instruction and facilitate collaboration among students. While digital transformation offers many benefits, it also presents challenges, such as the digital divide and the need for new pedagogical approaches. Ensuring that all students have equal access to technology and developing digital literacy skills are crucial for preparing them for success in the 21st century.	intermediate	130	Technology,Education,Digital	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0004j2qmhp40mi32	The History of the Olympic Games	The Olympic Games have a long and storied history, dating back to ancient Greece. The first recorded Olympic Games were held in 776 BC in Olympia, as a festival to honor the god Zeus. These ancient games featured various athletic competitions, including running, wrestling, and chariot racing. The modern Olympic Games were revived in 1896 by Pierre de Coubertin, who envisioned them as a way to promote international understanding and peace through sport. Today, the Olympics are a global event, bringing together thousands of athletes from around the world to compete in a wide range of summer and winter sports. The Games continue to inspire people with their message of excellence, friendship, and respect.	beginner	128	History,Sports,Culture	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0005j2qml4fftvs3	The Benefits of Regular Exercise	Regular physical activity is one of the most important things you can do for your health. It can help you manage your weight, reduce your risk of chronic diseases such as heart disease and diabetes, and strengthen your bones and muscles. Exercise also has significant mental health benefits, including reducing stress, anxiety, and depression. Whether it's a brisk walk, a swim, or a yoga session, finding an activity you enjoy and making it a part of your daily routine can greatly improve your overall well-being. Aim for at least 150 minutes of moderate-intensity aerobic activity per week, along with muscle-strengthening activities on two or more days. The rewards of staying active are well worth the effort.	beginner	126	Health,Fitness,Lifestyle	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0006j2qmitwaia84	Artificial Intelligence in Healthcare	Artificial Intelligence (AI) is revolutionizing the healthcare industry by enhancing diagnostic accuracy, personalizing treatment plans, and improving patient outcomes. AI algorithms can analyze vast amounts of medical data, including imaging and genomic information, to identify patterns that might be missed by human clinicians. This technology is being used to detect diseases like cancer at earlier stages and to develop more effective drugs and therapies. Furthermore, AI-powered virtual assistants and chatbots are providing patients with 24/7 support and personalized health advice. While AI offers immense potential, it also raises ethical concerns regarding data privacy and the role of human judgment in medical decision-making. As AI continues to evolve, its integration into healthcare must be carefully managed to ensure it benefits all patients.	advanced	132	Technology,Healthcare,AI	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0007j2qmhyzdt215	The Future of Space Exploration	Space exploration has entered a new era, with both government agencies and private companies working to reach new frontiers. Missions to Mars, the establishment of lunar bases, and the search for extraterrestrial life are among the ambitious goals of current and future space programs. Advances in rocket technology and robotics are making these missions more feasible and cost-effective. Additionally, space exploration has the potential to yield significant scientific discoveries and technological innovations that can benefit life on Earth. However, the challenges of long-duration space travel, including radiation exposure and resource management, remain significant. As we look to the stars, international collaboration and a shared vision for the peaceful use of space will be essential for the continued success of our journey into the cosmos.	intermediate	134	Science,Space,Future	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
\.


--
-- Data for Name: user_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_progress (id, "userId", "testType", "latestScore", "testsCompleted", "lastTestDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_study_streaks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_study_streaks (id, "userId", "currentStreak", "longestStreak", "totalStudyDays", "lastStudyDate", "weeklyGoal", "weeklyProgress", "createdAt", "updatedAt") FROM stdin;
1	8	1	1	1	2026-04-21 19:00:00	5	0	2026-04-22 05:40:17.267	2026-04-22 05:40:17.267
\.


--
-- Data for Name: weakness_analysis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weakness_analysis (id, "userId", "skillArea", "testType", "difficultyLevel", "failureCount", "attemptCount", "successRate", "averageScore", "lastFailedAt", priority, recommendation, "createdAt", "updatedAt") FROM stdin;
1	8	LISTENING_COMPREHENSION	LISTENING	5	1	1	0	0	2026-04-22 05:40:17.276	3	Practice daily listening with podcasts and lectures. Take notes while listening.	2026-04-22 05:40:17.277	2026-04-22 05:40:17.277
\.


--
-- Name: AIWritingAssessment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AIWritingAssessment_id_seq"', 5, true);


--
-- Name: AdminTask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AdminTask_id_seq"', 1, false);


--
-- Name: AiChatSession_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AiChatSession_id_seq"', 20, true);


--
-- Name: Device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Device_id_seq"', 1, false);


--
-- Name: Follow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Follow_id_seq"', 1, false);


--
-- Name: GroupApplication_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupApplication_id_seq"', 1, false);


--
-- Name: Inquiry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Inquiry_id_seq"', 1, false);


--
-- Name: Lesson_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Lesson_id_seq"', 1, false);


--
-- Name: LoginLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LoginLog_id_seq"', 1, false);


--
-- Name: Material_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Material_id_seq"', 1, false);


--
-- Name: MockResult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MockResult_id_seq"', 1, false);


--
-- Name: MockSession_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MockSession_id_seq"', 1, false);


--
-- Name: Notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Notification_id_seq"', 1, false);


--
-- Name: PartnerRequest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PartnerRequest_id_seq"', 1, false);


--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PasswordResetToken_id_seq"', 1, false);


--
-- Name: PracticeTestResult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PracticeTestResult_id_seq"', 1, false);


--
-- Name: PracticeTest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PracticeTest_id_seq"', 1, false);


--
-- Name: ProgressSnapshot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProgressSnapshot_id_seq"', 1, false);


--
-- Name: Question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Question_id_seq"', 1, false);


--
-- Name: Report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Report_id_seq"', 1, false);


--
-- Name: StrategicGoal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."StrategicGoal_id_seq"', 1, false);


--
-- Name: StudyGroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."StudyGroup_id_seq"', 1, false);


--
-- Name: StudyStreak_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."StudyStreak_id_seq"', 10, true);


--
-- Name: TestUnlock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TestUnlock_id_seq"', 1, false);


--
-- Name: TypingResult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TypingResult_id_seq"', 10, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 11, true);


--
-- Name: VerificationCode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VerificationCode_id_seq"', 4, true);


--
-- Name: WeeklyProgress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."WeeklyProgress_id_seq"', 1, false);


--
-- Name: centres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.centres_id_seq', 5, true);


--
-- Name: daily_study_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.daily_study_logs_id_seq', 1, true);


--
-- Name: leaderboard_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leaderboard_entries_id_seq', 1, false);


--
-- Name: leaderboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.leaderboards_id_seq', 1, false);


--
-- Name: skill_statistics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.skill_statistics_id_seq', 1, true);


--
-- Name: test_attempts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.test_attempts_id_seq', 1, true);


--
-- Name: user_study_streaks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_study_streaks_id_seq', 1, true);


--
-- Name: weakness_analysis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.weakness_analysis_id_seq', 1, true);


--
-- Name: AIWritingAssessment AIWritingAssessment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AIWritingAssessment"
    ADD CONSTRAINT "AIWritingAssessment_pkey" PRIMARY KEY (id);


--
-- Name: AdminTask AdminTask_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminTask"
    ADD CONSTRAINT "AdminTask_pkey" PRIMARY KEY (id);


--
-- Name: AiChatSession AiChatSession_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AiChatSession"
    ADD CONSTRAINT "AiChatSession_pkey" PRIMARY KEY (id);


--
-- Name: Device Device_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_pkey" PRIMARY KEY (id);


--
-- Name: Follow Follow_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_pkey" PRIMARY KEY (id);


--
-- Name: GroupApplication GroupApplication_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_pkey" PRIMARY KEY (id);


--
-- Name: Inquiry Inquiry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inquiry"
    ADD CONSTRAINT "Inquiry_pkey" PRIMARY KEY (id);


--
-- Name: Lesson Lesson_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_pkey" PRIMARY KEY (id);


--
-- Name: LoginLog LoginLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_pkey" PRIMARY KEY (id);


--
-- Name: Material Material_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Material"
    ADD CONSTRAINT "Material_pkey" PRIMARY KEY (id);


--
-- Name: MockResult MockResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockResult"
    ADD CONSTRAINT "MockResult_pkey" PRIMARY KEY (id);


--
-- Name: MockSession MockSession_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockSession"
    ADD CONSTRAINT "MockSession_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PartnerRequest PartnerRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartnerRequest"
    ADD CONSTRAINT "PartnerRequest_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: PracticeTestResult PracticeTestResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTestResult"
    ADD CONSTRAINT "PracticeTestResult_pkey" PRIMARY KEY (id);


--
-- Name: PracticeTest PracticeTest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTest"
    ADD CONSTRAINT "PracticeTest_pkey" PRIMARY KEY (id);


--
-- Name: ProgressSnapshot ProgressSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProgressSnapshot"
    ADD CONSTRAINT "ProgressSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: Question Question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (id);


--
-- Name: Report Report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_pkey" PRIMARY KEY (id);


--
-- Name: StrategicGoal StrategicGoal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StrategicGoal"
    ADD CONSTRAINT "StrategicGoal_pkey" PRIMARY KEY (id);


--
-- Name: StudyGroup StudyGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyGroup"
    ADD CONSTRAINT "StudyGroup_pkey" PRIMARY KEY (id);


--
-- Name: StudyStreak StudyStreak_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyStreak"
    ADD CONSTRAINT "StudyStreak_pkey" PRIMARY KEY (id);


--
-- Name: TestUnlock TestUnlock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TestUnlock"
    ADD CONSTRAINT "TestUnlock_pkey" PRIMARY KEY (id);


--
-- Name: TypingResult TypingResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TypingResult"
    ADD CONSTRAINT "TypingResult_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: VerificationCode VerificationCode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VerificationCode"
    ADD CONSTRAINT "VerificationCode_pkey" PRIMARY KEY (id);


--
-- Name: WeeklyProgress WeeklyProgress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WeeklyProgress"
    ADD CONSTRAINT "WeeklyProgress_pkey" PRIMARY KEY (id);


--
-- Name: _Staff _Staff_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_Staff"
    ADD CONSTRAINT "_Staff_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: centres centres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centres
    ADD CONSTRAINT centres_pkey PRIMARY KEY (id);


--
-- Name: daily_study_logs daily_study_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_study_logs
    ADD CONSTRAINT daily_study_logs_pkey PRIMARY KEY (id);


--
-- Name: leaderboard_entries leaderboard_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_entries
    ADD CONSTRAINT leaderboard_entries_pkey PRIMARY KEY (id);


--
-- Name: leaderboards leaderboards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboards
    ADD CONSTRAINT leaderboards_pkey PRIMARY KEY (id);


--
-- Name: live_session_participants live_session_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_session_participants
    ADD CONSTRAINT live_session_participants_pkey PRIMARY KEY (id);


--
-- Name: live_sessions live_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: skill_statistics skill_statistics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_statistics
    ADD CONSTRAINT skill_statistics_pkey PRIMARY KEY (id);


--
-- Name: test_attempts test_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_attempts
    ADD CONSTRAINT test_attempts_pkey PRIMARY KEY (id);


--
-- Name: test_submissions test_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_submissions
    ADD CONSTRAINT test_submissions_pkey PRIMARY KEY (id);


--
-- Name: typing_practice_texts typing_practice_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.typing_practice_texts
    ADD CONSTRAINT typing_practice_texts_pkey PRIMARY KEY (id);


--
-- Name: user_progress user_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_pkey PRIMARY KEY (id);


--
-- Name: user_study_streaks user_study_streaks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_study_streaks
    ADD CONSTRAINT user_study_streaks_pkey PRIMARY KEY (id);


--
-- Name: weakness_analysis weakness_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_analysis
    ADD CONSTRAINT weakness_analysis_pkey PRIMARY KEY (id);


--
-- Name: AIWritingAssessment_createdAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AIWritingAssessment_createdAt_idx" ON public."AIWritingAssessment" USING btree ("createdAt");


--
-- Name: AIWritingAssessment_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AIWritingAssessment_userId_idx" ON public."AIWritingAssessment" USING btree ("userId");


--
-- Name: AdminTask_adminId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AdminTask_adminId_idx" ON public."AdminTask" USING btree ("adminId");


--
-- Name: AdminTask_isDone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AdminTask_isDone_idx" ON public."AdminTask" USING btree ("isDone");


--
-- Name: AiChatSession_category_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AiChatSession_category_idx" ON public."AiChatSession" USING btree (category);


--
-- Name: AiChatSession_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AiChatSession_userId_idx" ON public."AiChatSession" USING btree ("userId");


--
-- Name: Device_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Device_userId_idx" ON public."Device" USING btree ("userId");


--
-- Name: Follow_studentId_teacherId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Follow_studentId_teacherId_key" ON public."Follow" USING btree ("studentId", "teacherId");


--
-- Name: GroupApplication_studentId_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "GroupApplication_studentId_groupId_key" ON public."GroupApplication" USING btree ("studentId", "groupId");


--
-- Name: LoginLog_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "LoginLog_timestamp_idx" ON public."LoginLog" USING btree ("timestamp");


--
-- Name: LoginLog_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "LoginLog_userId_idx" ON public."LoginLog" USING btree ("userId");


--
-- Name: PartnerRequest_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PartnerRequest_email_key" ON public."PartnerRequest" USING btree (email);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: PracticeTestResult_testCategory_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PracticeTestResult_testCategory_idx" ON public."PracticeTestResult" USING btree ("testCategory");


--
-- Name: PracticeTestResult_testIdentifier_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PracticeTestResult_testIdentifier_idx" ON public."PracticeTestResult" USING btree ("testIdentifier");


--
-- Name: PracticeTestResult_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PracticeTestResult_userId_idx" ON public."PracticeTestResult" USING btree ("userId");


--
-- Name: PracticeTestResult_userId_testIdentifier_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PracticeTestResult_userId_testIdentifier_key" ON public."PracticeTestResult" USING btree ("userId", "testIdentifier");


--
-- Name: PracticeTest_testType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PracticeTest_testType_idx" ON public."PracticeTest" USING btree ("testType");


--
-- Name: ProgressSnapshot_snapshotDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProgressSnapshot_snapshotDate_idx" ON public."ProgressSnapshot" USING btree ("snapshotDate");


--
-- Name: ProgressSnapshot_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProgressSnapshot_userId_idx" ON public."ProgressSnapshot" USING btree ("userId");


--
-- Name: StudyStreak_userId_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "StudyStreak_userId_date_key" ON public."StudyStreak" USING btree ("userId", date);


--
-- Name: TestUnlock_userId_category_subcategory_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TestUnlock_userId_category_subcategory_key" ON public."TestUnlock" USING btree ("userId", category, subcategory);


--
-- Name: TypingResult_date_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TypingResult_date_idx" ON public."TypingResult" USING btree (date);


--
-- Name: TypingResult_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "TypingResult_userId_idx" ON public."TypingResult" USING btree ("userId");


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: WeeklyProgress_userId_weekStartDate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WeeklyProgress_userId_weekStartDate_key" ON public."WeeklyProgress" USING btree ("userId", "weekStartDate");


--
-- Name: _Staff_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_Staff_B_index" ON public."_Staff" USING btree ("B");


--
-- Name: accounts_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "accounts_provider_providerAccountId_key" ON public.accounts USING btree (provider, "providerAccountId");


--
-- Name: centres_city_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX centres_city_idx ON public.centres USING btree (city);


--
-- Name: centres_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX centres_code_idx ON public.centres USING btree (code);


--
-- Name: centres_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX centres_code_key ON public.centres USING btree (code);


--
-- Name: centres_latitude_longitude_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX centres_latitude_longitude_idx ON public.centres USING btree (latitude, longitude);


--
-- Name: centres_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX centres_name_key ON public.centres USING btree (name);


--
-- Name: daily_study_logs_userId_studyDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "daily_study_logs_userId_studyDate_idx" ON public.daily_study_logs USING btree ("userId", "studyDate");


--
-- Name: daily_study_logs_userId_studyDate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "daily_study_logs_userId_studyDate_key" ON public.daily_study_logs USING btree ("userId", "studyDate");


--
-- Name: leaderboard_entries_leaderboardId_rank_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "leaderboard_entries_leaderboardId_rank_idx" ON public.leaderboard_entries USING btree ("leaderboardId", rank);


--
-- Name: leaderboard_entries_leaderboardId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "leaderboard_entries_leaderboardId_userId_key" ON public.leaderboard_entries USING btree ("leaderboardId", "userId");


--
-- Name: leaderboards_category_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX leaderboards_category_key ON public.leaderboards USING btree (category);


--
-- Name: live_session_participants_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "live_session_participants_sessionId_idx" ON public.live_session_participants USING btree ("sessionId");


--
-- Name: live_session_participants_sessionId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "live_session_participants_sessionId_userId_key" ON public.live_session_participants USING btree ("sessionId", "userId");


--
-- Name: live_session_participants_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "live_session_participants_userId_idx" ON public.live_session_participants USING btree ("userId");


--
-- Name: live_sessions_startTime_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "live_sessions_startTime_idx" ON public.live_sessions USING btree ("startTime");


--
-- Name: live_sessions_teacherId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "live_sessions_teacherId_idx" ON public.live_sessions USING btree ("teacherId");


--
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- Name: skill_statistics_userId_skill_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "skill_statistics_userId_skill_key" ON public.skill_statistics USING btree ("userId", skill);


--
-- Name: test_attempts_completedAt_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "test_attempts_completedAt_idx" ON public.test_attempts USING btree ("completedAt");


--
-- Name: test_attempts_testType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "test_attempts_testType_idx" ON public.test_attempts USING btree ("testType");


--
-- Name: test_attempts_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "test_attempts_userId_idx" ON public.test_attempts USING btree ("userId");


--
-- Name: test_attempts_userId_testType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "test_attempts_userId_testType_idx" ON public.test_attempts USING btree ("userId", "testType");


--
-- Name: typing_practice_texts_difficulty_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX typing_practice_texts_difficulty_idx ON public.typing_practice_texts USING btree (difficulty);


--
-- Name: typing_practice_texts_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "typing_practice_texts_isActive_idx" ON public.typing_practice_texts USING btree ("isActive");


--
-- Name: user_progress_userId_testType_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_progress_userId_testType_key" ON public.user_progress USING btree ("userId", "testType");


--
-- Name: user_study_streaks_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_study_streaks_userId_key" ON public.user_study_streaks USING btree ("userId");


--
-- Name: weakness_analysis_userId_priority_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "weakness_analysis_userId_priority_idx" ON public.weakness_analysis USING btree ("userId", priority);


--
-- Name: weakness_analysis_userId_skillArea_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "weakness_analysis_userId_skillArea_key" ON public.weakness_analysis USING btree ("userId", "skillArea");


--
-- Name: AIWritingAssessment AIWritingAssessment_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AIWritingAssessment"
    ADD CONSTRAINT "AIWritingAssessment_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AdminTask AdminTask_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminTask"
    ADD CONSTRAINT "AdminTask_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AiChatSession AiChatSession_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AiChatSession"
    ADD CONSTRAINT "AiChatSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Device Device_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Follow Follow_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Follow Follow_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GroupApplication GroupApplication_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."StudyGroup"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GroupApplication GroupApplication_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Inquiry Inquiry_centreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inquiry"
    ADD CONSTRAINT "Inquiry_centreId_fkey" FOREIGN KEY ("centreId") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Lesson Lesson_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LoginLog LoginLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Material Material_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Material"
    ADD CONSTRAINT "Material_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public."Lesson"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Material Material_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Material"
    ADD CONSTRAINT "Material_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MockResult MockResult_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockResult"
    ADD CONSTRAINT "MockResult_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."MockSession"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MockResult MockResult_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockResult"
    ADD CONSTRAINT "MockResult_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MockSession MockSession_centreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockSession"
    ADD CONSTRAINT "MockSession_centreId_fkey" FOREIGN KEY ("centreId") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PracticeTestResult PracticeTestResult_testId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTestResult"
    ADD CONSTRAINT "PracticeTestResult_testId_fkey" FOREIGN KEY ("testId") REFERENCES public."PracticeTest"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PracticeTestResult PracticeTestResult_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTestResult"
    ADD CONSTRAINT "PracticeTestResult_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PracticeTest PracticeTest_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTest"
    ADD CONSTRAINT "PracticeTest_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProgressSnapshot ProgressSnapshot_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProgressSnapshot"
    ADD CONSTRAINT "ProgressSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Question Question_testId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_testId_fkey" FOREIGN KEY ("testId") REFERENCES public."PracticeTest"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Report Report_questionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES public."Question"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Report Report_resolvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_resolvedById_fkey" FOREIGN KEY ("resolvedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Report Report_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Report Report_testId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_testId_fkey" FOREIGN KEY ("testId") REFERENCES public."PracticeTest"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StudyGroup StudyGroup_centreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyGroup"
    ADD CONSTRAINT "StudyGroup_centreId_fkey" FOREIGN KEY ("centreId") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StudyGroup StudyGroup_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyGroup"
    ADD CONSTRAINT "StudyGroup_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StudyStreak StudyStreak_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyStreak"
    ADD CONSTRAINT "StudyStreak_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TestUnlock TestUnlock_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TestUnlock"
    ADD CONSTRAINT "TestUnlock_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TypingResult TypingResult_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TypingResult"
    ADD CONSTRAINT "TypingResult_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_centreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_centreId_fkey" FOREIGN KEY ("centreId") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WeeklyProgress WeeklyProgress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WeeklyProgress"
    ADD CONSTRAINT "WeeklyProgress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _Staff _Staff_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_Staff"
    ADD CONSTRAINT "_Staff_A_fkey" FOREIGN KEY ("A") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _Staff _Staff_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_Staff"
    ADD CONSTRAINT "_Staff_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: announcements announcements_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT "announcements_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: centres centres_managerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centres
    ADD CONSTRAINT "centres_managerId_fkey" FOREIGN KEY ("managerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: daily_study_logs daily_study_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.daily_study_logs
    ADD CONSTRAINT "daily_study_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leaderboard_entries leaderboard_entries_leaderboardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_entries
    ADD CONSTRAINT "leaderboard_entries_leaderboardId_fkey" FOREIGN KEY ("leaderboardId") REFERENCES public.leaderboards(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: leaderboard_entries leaderboard_entries_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.leaderboard_entries
    ADD CONSTRAINT "leaderboard_entries_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: live_session_participants live_session_participants_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_session_participants
    ADD CONSTRAINT "live_session_participants_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.live_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: live_session_participants live_session_participants_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_session_participants
    ADD CONSTRAINT "live_session_participants_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: live_sessions live_sessions_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT "live_sessions_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: skill_statistics skill_statistics_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skill_statistics
    ADD CONSTRAINT "skill_statistics_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: test_attempts test_attempts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_attempts
    ADD CONSTRAINT "test_attempts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: test_submissions test_submissions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_submissions
    ADD CONSTRAINT "test_submissions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_progress user_progress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT "user_progress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_study_streaks user_study_streaks_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_study_streaks
    ADD CONSTRAINT "user_study_streaks_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: weakness_analysis weakness_analysis_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weakness_analysis
    ADD CONSTRAINT "weakness_analysis_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict hgHBsDwEQteZEmbhHY65MqAOjw5730TD3zzZgRdPbWnOJGksKxmQSuOhQuEbliG

