--
-- PostgreSQL database dump
--

\restrict 53hBTjhUWzkal73CNuqSBIQ8irv4MPzK3IdavEWcdW0KP3Do2aeGoArKQuSBBLt

-- Dumped from database version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.13 (Ubuntu 16.13-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS '';


--
-- Name: ApplicationStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ApplicationStatus" AS ENUM (
    'PENDING',
    'ACCEPTED',
    'DECLINED'
);


ALTER TYPE public."ApplicationStatus" OWNER TO postgres;

--
-- Name: DeviceType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."DeviceType" AS ENUM (
    'DESKTOP',
    'LAPTOP',
    'MOBILE',
    'TABLET'
);


ALTER TYPE public."DeviceType" OWNER TO postgres;

--
-- Name: GroupLevel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."GroupLevel" AS ENUM (
    'BEGINNER',
    'INTERMEDIATE',
    'ADVANCED'
);


ALTER TYPE public."GroupLevel" OWNER TO postgres;

--
-- Name: GroupStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."GroupStatus" AS ENUM (
    'OPEN',
    'CLOSED'
);


ALTER TYPE public."GroupStatus" OWNER TO postgres;

--
-- Name: PartnerStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PartnerStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'REJECTED'
);


ALTER TYPE public."PartnerStatus" OWNER TO postgres;

--
-- Name: PracticeMode; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."PracticeMode" AS ENUM (
    'FULL',
    'PARTIAL'
);


ALTER TYPE public."PracticeMode" OWNER TO postgres;

--
-- Name: QuestionType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."QuestionType" AS ENUM (
    'MULTIPLE_CHOICE',
    'FILL_BLANKS',
    'TRUE_FALSE'
);


ALTER TYPE public."QuestionType" OWNER TO postgres;

--
-- Name: ReportStatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ReportStatus" AS ENUM (
    'OPEN',
    'REVIEWING',
    'RESOLVED',
    'WONT_FIX'
);


ALTER TYPE public."ReportStatus" OWNER TO postgres;

--
-- Name: ReportType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."ReportType" AS ENUM (
    'CONTENT_ERROR',
    'TECHNICAL_BUG',
    'SCORE_ERROR',
    'TYPO',
    'OTHER'
);


ALTER TYPE public."ReportType" OWNER TO postgres;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."Role" AS ENUM (
    'STUDENT',
    'ADMIN',
    'CEO',
    'CENTRE',
    'TEACHER',
    'GRADER',
    'SUPPORT',
    'CONTENT',
    'ANALYST',
    'MANAGER'
);


ALTER TYPE public."Role" OWNER TO postgres;

--
-- Name: TaskLabel; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskLabel" AS ENUM (
    'CUSTOMER_SERVICE',
    'TECHNICAL_ANALYSIS',
    'CONTENT_MANAGEMENT',
    'OPERATIONS'
);


ALTER TYPE public."TaskLabel" OWNER TO postgres;

--
-- Name: TaskPriority; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TaskPriority" AS ENUM (
    'HIGH',
    'MEDIUM',
    'LOW'
);


ALTER TYPE public."TaskPriority" OWNER TO postgres;

--
-- Name: TestType; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public."TestType" AS ENUM (
    'READING',
    'LISTENING',
    'WRITING',
    'SPEAKING'
);


ALTER TYPE public."TestType" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AdminTask; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AdminTask" (
    id integer NOT NULL,
    "adminId" integer NOT NULL,
    title text NOT NULL,
    notes text,
    label public."TaskLabel" DEFAULT 'CUSTOMER_SERVICE'::public."TaskLabel" NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "isDone" boolean DEFAULT false NOT NULL,
    "doneAt" timestamp(3) without time zone,
    "assignedDate" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."AdminTask" OWNER TO postgres;

--
-- Name: AdminTask_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AdminTask_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AdminTask_id_seq" OWNER TO postgres;

--
-- Name: AdminTask_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AdminTask_id_seq" OWNED BY public."AdminTask".id;


--
-- Name: AiChatSession; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AiChatSession" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    topic text DEFAULT 'General'::text NOT NULL,
    "messageCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    history jsonb
);


ALTER TABLE public."AiChatSession" OWNER TO postgres;

--
-- Name: AiChatSession_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AiChatSession_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."AiChatSession_id_seq" OWNER TO postgres;

--
-- Name: AiChatSession_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AiChatSession_id_seq" OWNED BY public."AiChatSession".id;


--
-- Name: Device; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Device" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "deviceType" public."DeviceType" DEFAULT 'DESKTOP'::public."DeviceType" NOT NULL,
    "deviceName" text NOT NULL,
    browser text NOT NULL,
    os text,
    "ipAddress" text,
    location text,
    latitude double precision,
    longitude double precision,
    "userAgent" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastActiveAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Device" OWNER TO postgres;

--
-- Name: Device_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Device_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Device_id_seq" OWNER TO postgres;

--
-- Name: Device_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Device_id_seq" OWNED BY public."Device".id;


--
-- Name: Follow; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Follow" (
    id integer NOT NULL,
    "studentId" integer NOT NULL,
    "teacherId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Follow" OWNER TO postgres;

--
-- Name: Follow_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Follow_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Follow_id_seq" OWNER TO postgres;

--
-- Name: Follow_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Follow_id_seq" OWNED BY public."Follow".id;


--
-- Name: GroupApplication; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."GroupApplication" (
    id integer NOT NULL,
    "studentId" integer NOT NULL,
    "groupId" integer NOT NULL,
    status public."ApplicationStatus" DEFAULT 'PENDING'::public."ApplicationStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."GroupApplication" OWNER TO postgres;

--
-- Name: GroupApplication_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."GroupApplication_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."GroupApplication_id_seq" OWNER TO postgres;

--
-- Name: GroupApplication_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."GroupApplication_id_seq" OWNED BY public."GroupApplication".id;


--
-- Name: Inquiry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Inquiry" (
    id integer NOT NULL,
    "centreId" integer NOT NULL,
    "studentName" text NOT NULL,
    "studentEmail" text NOT NULL,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Inquiry" OWNER TO postgres;

--
-- Name: Inquiry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Inquiry_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Inquiry_id_seq" OWNER TO postgres;

--
-- Name: Inquiry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Inquiry_id_seq" OWNED BY public."Inquiry".id;


--
-- Name: Lesson; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Lesson" (
    id integer NOT NULL,
    title text NOT NULL,
    "zoomLink" text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'SCHEDULED'::text NOT NULL,
    "teacherId" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Lesson" OWNER TO postgres;

--
-- Name: Lesson_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Lesson_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Lesson_id_seq" OWNER TO postgres;

--
-- Name: Lesson_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Lesson_id_seq" OWNED BY public."Lesson".id;


--
-- Name: LoginLog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LoginLog" (
    id integer NOT NULL,
    "userId" integer,
    "ipAddress" text,
    "deviceInfo" text,
    "userAgent" text,
    success boolean NOT NULL,
    reason text,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."LoginLog" OWNER TO postgres;

--
-- Name: LoginLog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LoginLog_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."LoginLog_id_seq" OWNER TO postgres;

--
-- Name: LoginLog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LoginLog_id_seq" OWNED BY public."LoginLog".id;


--
-- Name: Material; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Material" (
    id integer NOT NULL,
    "fileName" text NOT NULL,
    "fileUrl" text NOT NULL,
    "fileType" text NOT NULL,
    "teacherId" integer NOT NULL,
    "lessonId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Material" OWNER TO postgres;

--
-- Name: Material_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Material_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Material_id_seq" OWNER TO postgres;

--
-- Name: Material_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Material_id_seq" OWNED BY public."Material".id;


--
-- Name: MockResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MockResult" (
    id integer NOT NULL,
    "studentId" integer NOT NULL,
    "sessionId" integer,
    listening double precision,
    reading double precision,
    writing double precision,
    speaking double precision,
    overall double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MockResult" OWNER TO postgres;

--
-- Name: MockResult_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MockResult_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MockResult_id_seq" OWNER TO postgres;

--
-- Name: MockResult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MockResult_id_seq" OWNED BY public."MockResult".id;


--
-- Name: MockSession; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MockSession" (
    id integer NOT NULL,
    "centreId" integer NOT NULL,
    "dateTime" timestamp(3) without time zone NOT NULL,
    type text DEFAULT 'Academic'::text NOT NULL,
    format text DEFAULT 'Paper-Based'::text NOT NULL,
    location text DEFAULT 'TBD'::text NOT NULL,
    capacity integer DEFAULT 30 NOT NULL,
    price double precision DEFAULT 0 NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."MockSession" OWNER TO postgres;

--
-- Name: MockSession_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MockSession_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MockSession_id_seq" OWNER TO postgres;

--
-- Name: MockSession_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MockSession_id_seq" OWNED BY public."MockSession".id;


--
-- Name: Notification; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Notification" (
    id integer NOT NULL,
    icon text DEFAULT '🔔'::text NOT NULL,
    message text NOT NULL,
    "isRead" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Notification" OWNER TO postgres;

--
-- Name: Notification_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Notification_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Notification_id_seq" OWNER TO postgres;

--
-- Name: Notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Notification_id_seq" OWNED BY public."Notification".id;


--
-- Name: PartnerRequest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PartnerRequest" (
    id integer NOT NULL,
    centre_name text NOT NULL,
    ceo_name text NOT NULL,
    email text NOT NULL,
    phone text NOT NULL,
    location text NOT NULL,
    status public."PartnerStatus" DEFAULT 'PENDING'::public."PartnerStatus" NOT NULL,
    password text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PartnerRequest" OWNER TO postgres;

--
-- Name: PartnerRequest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PartnerRequest_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PartnerRequest_id_seq" OWNER TO postgres;

--
-- Name: PartnerRequest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PartnerRequest_id_seq" OWNED BY public."PartnerRequest".id;


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PasswordResetToken" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordResetToken" OWNER TO postgres;

--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PasswordResetToken_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PasswordResetToken_id_seq" OWNER TO postgres;

--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PasswordResetToken_id_seq" OWNED BY public."PasswordResetToken".id;


--
-- Name: PracticeTest; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PracticeTest" (
    id integer NOT NULL,
    title text NOT NULL,
    "testType" public."TestType" NOT NULL,
    "practiceMode" public."PracticeMode" DEFAULT 'FULL'::public."PracticeMode" NOT NULL,
    "focusArea" text,
    "durationMins" integer DEFAULT 60 NOT NULL,
    instructions text,
    passage text,
    "audioUrl" text,
    "isPublished" boolean DEFAULT false NOT NULL,
    "isArchived" boolean DEFAULT false NOT NULL,
    "createdById" integer NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PracticeTest" OWNER TO postgres;

--
-- Name: PracticeTestResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."PracticeTestResult" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "testId" integer NOT NULL,
    "testIdentifier" text NOT NULL,
    "testCategory" text NOT NULL,
    "testSubcategory" text,
    "setNumber" integer NOT NULL,
    score double precision DEFAULT 0 NOT NULL,
    "bandScore" double precision,
    "correctAnswers" integer DEFAULT 0 NOT NULL,
    "totalQuestions" integer DEFAULT 0 NOT NULL,
    "timeSpentSeconds" integer DEFAULT 0 NOT NULL,
    answers jsonb,
    "isCompleted" boolean DEFAULT false NOT NULL,
    "isUnlocked" boolean DEFAULT true NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "aiAnalysis" text,
    "progressNote" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."PracticeTestResult" OWNER TO postgres;

--
-- Name: PracticeTestResult_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PracticeTestResult_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PracticeTestResult_id_seq" OWNER TO postgres;

--
-- Name: PracticeTestResult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PracticeTestResult_id_seq" OWNED BY public."PracticeTestResult".id;


--
-- Name: PracticeTest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."PracticeTest_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."PracticeTest_id_seq" OWNER TO postgres;

--
-- Name: PracticeTest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."PracticeTest_id_seq" OWNED BY public."PracticeTest".id;


--
-- Name: ProgressSnapshot; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ProgressSnapshot" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "listeningAvg" double precision DEFAULT 0,
    "readingAvg" double precision DEFAULT 0,
    "writingAvg" double precision DEFAULT 0,
    "speakingAvg" double precision DEFAULT 0,
    "overallAvg" double precision DEFAULT 0,
    "estimatedBand" double precision DEFAULT 5.0,
    "targetBand" double precision DEFAULT 8.0,
    "testsCompleted" integer DEFAULT 0 NOT NULL,
    "currentStreak" integer DEFAULT 0 NOT NULL,
    "bestStreak" integer DEFAULT 0 NOT NULL,
    "weakAreas" text,
    "strongAreas" text,
    "isMakingProgress" boolean DEFAULT true NOT NULL,
    "aiConclusion" text,
    recommendation text,
    "snapshotDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."ProgressSnapshot" OWNER TO postgres;

--
-- Name: ProgressSnapshot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ProgressSnapshot_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."ProgressSnapshot_id_seq" OWNER TO postgres;

--
-- Name: ProgressSnapshot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ProgressSnapshot_id_seq" OWNED BY public."ProgressSnapshot".id;


--
-- Name: Question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Question" (
    id integer NOT NULL,
    "testId" integer NOT NULL,
    "questionText" text NOT NULL,
    type public."QuestionType" DEFAULT 'MULTIPLE_CHOICE'::public."QuestionType" NOT NULL,
    options jsonb,
    "correctAnswer" text NOT NULL,
    "orderIndex" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Question" OWNER TO postgres;

--
-- Name: Question_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Question_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Question_id_seq" OWNER TO postgres;

--
-- Name: Question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Question_id_seq" OWNED BY public."Question".id;


--
-- Name: Report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Report" (
    id integer NOT NULL,
    "studentId" integer NOT NULL,
    "testId" integer NOT NULL,
    "questionId" integer,
    type public."ReportType" DEFAULT 'CONTENT_ERROR'::public."ReportType" NOT NULL,
    status public."ReportStatus" DEFAULT 'OPEN'::public."ReportStatus" NOT NULL,
    description text NOT NULL,
    "resolvedById" integer,
    "resolutionNote" text,
    "resolvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Report" OWNER TO postgres;

--
-- Name: Report_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Report_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Report_id_seq" OWNER TO postgres;

--
-- Name: Report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Report_id_seq" OWNED BY public."Report".id;


--
-- Name: StrategicGoal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StrategicGoal" (
    id integer NOT NULL,
    title text NOT NULL,
    priority public."TaskPriority" DEFAULT 'MEDIUM'::public."TaskPriority" NOT NULL,
    "column" text DEFAULT 'TODO'::text NOT NULL,
    "dueDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StrategicGoal" OWNER TO postgres;

--
-- Name: StrategicGoal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."StrategicGoal_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StrategicGoal_id_seq" OWNER TO postgres;

--
-- Name: StrategicGoal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."StrategicGoal_id_seq" OWNED BY public."StrategicGoal".id;


--
-- Name: StudyGroup; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StudyGroup" (
    id integer NOT NULL,
    "centreId" integer NOT NULL,
    "teacherId" integer,
    name text NOT NULL,
    level text DEFAULT 'All levels'::text NOT NULL,
    schedule text DEFAULT 'TBD'::text NOT NULL,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    capacity integer DEFAULT 15 NOT NULL,
    status public."GroupStatus" DEFAULT 'OPEN'::public."GroupStatus" NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."StudyGroup" OWNER TO postgres;

--
-- Name: StudyGroup_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."StudyGroup_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StudyGroup_id_seq" OWNER TO postgres;

--
-- Name: StudyGroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."StudyGroup_id_seq" OWNED BY public."StudyGroup".id;


--
-- Name: StudyStreak; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."StudyStreak" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    date date NOT NULL,
    "isCompleted" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."StudyStreak" OWNER TO postgres;

--
-- Name: StudyStreak_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."StudyStreak_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."StudyStreak_id_seq" OWNER TO postgres;

--
-- Name: StudyStreak_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."StudyStreak_id_seq" OWNED BY public."StudyStreak".id;


--
-- Name: TestUnlock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TestUnlock" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    category text NOT NULL,
    subcategory text,
    "maxUnlockedSet" integer DEFAULT 1 NOT NULL,
    "minScoreRequired" double precision DEFAULT 70.0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."TestUnlock" OWNER TO postgres;

--
-- Name: TestUnlock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TestUnlock_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TestUnlock_id_seq" OWNER TO postgres;

--
-- Name: TestUnlock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TestUnlock_id_seq" OWNED BY public."TestUnlock".id;


--
-- Name: TypingResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TypingResult" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    wpm double precision NOT NULL,
    accuracy double precision NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "durationMinutes" integer DEFAULT 2
);


ALTER TABLE public."TypingResult" OWNER TO postgres;

--
-- Name: TypingResult_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TypingResult_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TypingResult_id_seq" OWNER TO postgres;

--
-- Name: TypingResult_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TypingResult_id_seq" OWNED BY public."TypingResult".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    full_name text NOT NULL,
    name text,
    email text NOT NULL,
    username text,
    password text,
    country text,
    phone text,
    test_type text,
    role public."Role" DEFAULT 'STUDENT'::public."Role" NOT NULL,
    is_verified boolean DEFAULT false NOT NULL,
    "isVerified" boolean DEFAULT false,
    is_onboarded boolean DEFAULT false NOT NULL,
    "isOnboarded" boolean DEFAULT false,
    target_band double precision DEFAULT 8.0,
    "targetBand" double precision DEFAULT 8.0,
    current_band double precision DEFAULT 5.0 NOT NULL,
    "currentBand" double precision DEFAULT 5.0,
    study_hours double precision DEFAULT 0 NOT NULL,
    tasks_done integer DEFAULT 0 NOT NULL,
    "tasksDone" integer DEFAULT 0,
    weekly_goal_percent double precision DEFAULT 0 NOT NULL,
    exam_date timestamp(3) without time zone,
    "examDate" timestamp(3) without time zone,
    exam_date_text text,
    target_band_range text,
    study_commitment text,
    referral_source text,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastSeenAt" timestamp(3) without time zone,
    "isExamDateUnsure" boolean DEFAULT true NOT NULL,
    "sourceOfExposure" text,
    "onboardingComplete" boolean DEFAULT false NOT NULL,
    "centreId" integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: VerificationCode; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VerificationCode" (
    id integer NOT NULL,
    email text NOT NULL,
    code text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."VerificationCode" OWNER TO postgres;

--
-- Name: VerificationCode_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VerificationCode_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."VerificationCode_id_seq" OWNER TO postgres;

--
-- Name: VerificationCode_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VerificationCode_id_seq" OWNED BY public."VerificationCode".id;


--
-- Name: WeeklyProgress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."WeeklyProgress" (
    id integer NOT NULL,
    "userId" integer NOT NULL,
    "weekStartDate" date NOT NULL,
    "perfectScoresCount" integer DEFAULT 0 NOT NULL,
    "progressPercentage" double precision DEFAULT 0 NOT NULL
);


ALTER TABLE public."WeeklyProgress" OWNER TO postgres;

--
-- Name: WeeklyProgress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."WeeklyProgress_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."WeeklyProgress_id_seq" OWNER TO postgres;

--
-- Name: WeeklyProgress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."WeeklyProgress_id_seq" OWNED BY public."WeeklyProgress".id;


--
-- Name: _Staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."_Staff" (
    "A" integer NOT NULL,
    "B" integer NOT NULL
);


ALTER TABLE public."_Staff" OWNER TO postgres;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO postgres;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    "userId" integer NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.announcements (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    type text DEFAULT 'GENERAL'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "createdBy" integer NOT NULL
);


ALTER TABLE public.announcements OWNER TO postgres;

--
-- Name: centres; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.centres (
    id integer NOT NULL,
    name text NOT NULL,
    code text NOT NULL,
    city text NOT NULL,
    address text,
    phone text,
    website text,
    "totalStudents" integer DEFAULT 0 NOT NULL,
    "activeStudents" integer DEFAULT 0 NOT NULL,
    rating double precision DEFAULT 4.5,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    country text NOT NULL,
    email text,
    "managerId" integer,
    latitude double precision,
    longitude double precision
);


ALTER TABLE public.centres OWNER TO postgres;

--
-- Name: centres_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.centres_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.centres_id_seq OWNER TO postgres;

--
-- Name: centres_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.centres_id_seq OWNED BY public.centres.id;


--
-- Name: live_session_participants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.live_session_participants (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    "userId" integer NOT NULL,
    "joinedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "leftAt" timestamp(3) without time zone,
    role text DEFAULT 'student'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.live_session_participants OWNER TO postgres;

--
-- Name: live_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.live_sessions (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "teacherId" integer NOT NULL,
    "sessionType" text DEFAULT 'speaking'::text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone,
    "maxParticipants" integer DEFAULT 20 NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    "isFeatured" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.live_sessions OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" integer NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- Name: test_submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_submissions (
    id text NOT NULL,
    "userId" integer NOT NULL,
    "testId" text NOT NULL,
    "testType" public."TestType" NOT NULL,
    answers jsonb NOT NULL,
    score double precision NOT NULL,
    "bandScore" double precision,
    "timeSpent" integer NOT NULL,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "gradedAt" timestamp(3) without time zone,
    feedback jsonb
);


ALTER TABLE public.test_submissions OWNER TO postgres;

--
-- Name: typing_practice_texts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.typing_practice_texts (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    difficulty text DEFAULT 'intermediate'::text NOT NULL,
    "wordCount" integer NOT NULL,
    topics text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.typing_practice_texts OWNER TO postgres;

--
-- Name: user_progress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_progress (
    id text NOT NULL,
    "userId" integer NOT NULL,
    "testType" public."TestType" NOT NULL,
    "latestScore" double precision NOT NULL,
    "testsCompleted" integer DEFAULT 0 NOT NULL,
    "lastTestDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.user_progress OWNER TO postgres;

--
-- Name: AdminTask id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminTask" ALTER COLUMN id SET DEFAULT nextval('public."AdminTask_id_seq"'::regclass);


--
-- Name: AiChatSession id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AiChatSession" ALTER COLUMN id SET DEFAULT nextval('public."AiChatSession_id_seq"'::regclass);


--
-- Name: Device id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Device" ALTER COLUMN id SET DEFAULT nextval('public."Device_id_seq"'::regclass);


--
-- Name: Follow id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Follow" ALTER COLUMN id SET DEFAULT nextval('public."Follow_id_seq"'::regclass);


--
-- Name: GroupApplication id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication" ALTER COLUMN id SET DEFAULT nextval('public."GroupApplication_id_seq"'::regclass);


--
-- Name: Inquiry id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inquiry" ALTER COLUMN id SET DEFAULT nextval('public."Inquiry_id_seq"'::regclass);


--
-- Name: Lesson id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson" ALTER COLUMN id SET DEFAULT nextval('public."Lesson_id_seq"'::regclass);


--
-- Name: LoginLog id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginLog" ALTER COLUMN id SET DEFAULT nextval('public."LoginLog_id_seq"'::regclass);


--
-- Name: Material id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Material" ALTER COLUMN id SET DEFAULT nextval('public."Material_id_seq"'::regclass);


--
-- Name: MockResult id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockResult" ALTER COLUMN id SET DEFAULT nextval('public."MockResult_id_seq"'::regclass);


--
-- Name: MockSession id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockSession" ALTER COLUMN id SET DEFAULT nextval('public."MockSession_id_seq"'::regclass);


--
-- Name: Notification id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification" ALTER COLUMN id SET DEFAULT nextval('public."Notification_id_seq"'::regclass);


--
-- Name: PartnerRequest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartnerRequest" ALTER COLUMN id SET DEFAULT nextval('public."PartnerRequest_id_seq"'::regclass);


--
-- Name: PasswordResetToken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken" ALTER COLUMN id SET DEFAULT nextval('public."PasswordResetToken_id_seq"'::regclass);


--
-- Name: PracticeTest id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTest" ALTER COLUMN id SET DEFAULT nextval('public."PracticeTest_id_seq"'::regclass);


--
-- Name: PracticeTestResult id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTestResult" ALTER COLUMN id SET DEFAULT nextval('public."PracticeTestResult_id_seq"'::regclass);


--
-- Name: ProgressSnapshot id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProgressSnapshot" ALTER COLUMN id SET DEFAULT nextval('public."ProgressSnapshot_id_seq"'::regclass);


--
-- Name: Question id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question" ALTER COLUMN id SET DEFAULT nextval('public."Question_id_seq"'::regclass);


--
-- Name: Report id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report" ALTER COLUMN id SET DEFAULT nextval('public."Report_id_seq"'::regclass);


--
-- Name: StrategicGoal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StrategicGoal" ALTER COLUMN id SET DEFAULT nextval('public."StrategicGoal_id_seq"'::regclass);


--
-- Name: StudyGroup id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyGroup" ALTER COLUMN id SET DEFAULT nextval('public."StudyGroup_id_seq"'::regclass);


--
-- Name: StudyStreak id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyStreak" ALTER COLUMN id SET DEFAULT nextval('public."StudyStreak_id_seq"'::regclass);


--
-- Name: TestUnlock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TestUnlock" ALTER COLUMN id SET DEFAULT nextval('public."TestUnlock_id_seq"'::regclass);


--
-- Name: TypingResult id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TypingResult" ALTER COLUMN id SET DEFAULT nextval('public."TypingResult_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Name: VerificationCode id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VerificationCode" ALTER COLUMN id SET DEFAULT nextval('public."VerificationCode_id_seq"'::regclass);


--
-- Name: WeeklyProgress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WeeklyProgress" ALTER COLUMN id SET DEFAULT nextval('public."WeeklyProgress_id_seq"'::regclass);


--
-- Name: centres id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centres ALTER COLUMN id SET DEFAULT nextval('public.centres_id_seq'::regclass);


--
-- Data for Name: AdminTask; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AdminTask" (id, "adminId", title, notes, label, priority, "isDone", "doneAt", "assignedDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: AiChatSession; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AiChatSession" (id, "userId", topic, "messageCount", "createdAt", "updatedAt", history) FROM stdin;
\.


--
-- Data for Name: Device; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Device" (id, "userId", "deviceType", "deviceName", browser, os, "ipAddress", location, latitude, longitude, "userAgent", "isActive", "lastActiveAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Follow; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Follow" (id, "studentId", "teacherId", "createdAt") FROM stdin;
\.


--
-- Data for Name: GroupApplication; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."GroupApplication" (id, "studentId", "groupId", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Inquiry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Inquiry" (id, "centreId", "studentName", "studentEmail", message, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: Lesson; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Lesson" (id, title, "zoomLink", "startTime", status, "teacherId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: LoginLog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LoginLog" (id, "userId", "ipAddress", "deviceInfo", "userAgent", success, reason, "timestamp") FROM stdin;
\.


--
-- Data for Name: Material; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Material" (id, "fileName", "fileUrl", "fileType", "teacherId", "lessonId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MockResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MockResult" (id, "studentId", "sessionId", listening, reading, writing, speaking, overall, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: MockSession; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."MockSession" (id, "centreId", "dateTime", type, format, location, capacity, price, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Notification" (id, icon, message, "isRead", "createdAt") FROM stdin;
\.


--
-- Data for Name: PartnerRequest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PartnerRequest" (id, centre_name, ceo_name, email, phone, location, status, password, "createdAt") FROM stdin;
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PasswordResetToken" (id, "userId", token, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: PracticeTest; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PracticeTest" (id, title, "testType", "practiceMode", "focusArea", "durationMins", instructions, passage, "audioUrl", "isPublished", "isArchived", "createdById", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: PracticeTestResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."PracticeTestResult" (id, "userId", "testId", "testIdentifier", "testCategory", "testSubcategory", "setNumber", score, "bandScore", "correctAnswers", "totalQuestions", "timeSpentSeconds", answers, "isCompleted", "isUnlocked", "completedAt", "aiAnalysis", "progressNote", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: ProgressSnapshot; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ProgressSnapshot" (id, "userId", "listeningAvg", "readingAvg", "writingAvg", "speakingAvg", "overallAvg", "estimatedBand", "targetBand", "testsCompleted", "currentStreak", "bestStreak", "weakAreas", "strongAreas", "isMakingProgress", "aiConclusion", recommendation, "snapshotDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Question" (id, "testId", "questionText", type, options, "correctAnswer", "orderIndex", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Report" (id, "studentId", "testId", "questionId", type, status, description, "resolvedById", "resolutionNote", "resolvedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StrategicGoal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StrategicGoal" (id, title, priority, "column", "dueDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StudyGroup; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StudyGroup" (id, "centreId", "teacherId", name, level, schedule, "startDate", "endDate", capacity, status, description, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: StudyStreak; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."StudyStreak" (id, "userId", date, "isCompleted") FROM stdin;
\.


--
-- Data for Name: TestUnlock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TestUnlock" (id, "userId", category, subcategory, "maxUnlockedSet", "minScoreRequired", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: TypingResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."TypingResult" (id, "userId", wpm, accuracy, date, "durationMinutes") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, full_name, name, email, username, password, country, phone, test_type, role, is_verified, "isVerified", is_onboarded, "isOnboarded", target_band, "targetBand", current_band, "currentBand", study_hours, tasks_done, "tasksDone", weekly_goal_percent, exam_date, "examDate", exam_date_text, target_band_range, study_commitment, referral_source, "isActive", "lastSeenAt", "isExamDateUnsure", "sourceOfExposure", "onboardingComplete", "centreId", "createdAt", "updatedAt") FROM stdin;
5	CEO Account	\N	ceo@ieltspractice.com	\N	$2b$10$3kdKpbMzfF5lPUFFOE7xJuoj1xMVx7eh/I51yDVJ8yDb9YJyDx9AS	Uzbekistan	\N	\N	CEO	t	f	f	f	8	8	9	5	0	0	0	0	\N	\N	\N	\N	\N	\N	t	\N	t	\N	f	\N	2026-04-14 04:29:40.551	2026-04-14 04:29:40.551
6	Admin Account	\N	admin@ieltspractice.com	\N	$2b$10$1YOsmB0uFh48ppHgMkXZVOJoEHaVdpqTAjp58cH6gBbiD6x7z6blm	Uzbekistan	\N	\N	ADMIN	t	f	f	f	8	8	8	5	0	0	0	0	\N	\N	\N	\N	\N	\N	t	\N	t	\N	f	\N	2026-04-14 04:29:40.563	2026-04-14 04:29:40.563
9	a	a	sdjsk@gmail.com	sdjsk	$2b$12$iWTH7OVKxLt3MbNVYyRpKOwCwGHKzpHDrtHBav3n5SDMciJ.7jpQ2	Uzbekistan		Academic	STUDENT	t	f	t	f	7.5	7.5	5	5	0	0	0	0	2026-07-18 00:00:00	2026-07-18 00:00:00	2026-07-18	\N	\N	\N	t	2026-04-14 08:15:21.889	f	Friend	t	\N	2026-04-14 04:39:22.95	2026-04-14 10:24:18.75
7	Ahrorbek Xalimov	Ahrorbek Xalimov	khalimovahrorbek@gmail.com	ahror	$2b$12$cs5ZKHrhoKRmm0gfKkrxWOpT.lOP11KLFJg76fUA6duMnOzo2U5Vy	Uzbekistan	\N	\N	STUDENT	t	f	f	f	8	8	5	5	0	0	0	0	\N	\N	\N	\N	\N	\N	t	2026-04-14 04:45:54.345	t	\N	f	\N	2026-04-14 04:29:40.993	2026-04-14 04:45:54.347
8	sdsd dsd	sdsd dsd	dsd@gmail.com	moneycold	$2b$12$wlMmDEc7wHh1WPPtLTdT6uP.1hyRd9sm6cuPsaHfxv4j7BYE0KMzy	Uzbekistan		Academic	STUDENT	t	f	t	f	8.5	8.5	5	5	0	0	0	0	2026-11-13 00:00:00	2026-11-13 00:00:00	2026-11-13	\N	\N	\N	t	2026-04-18 19:03:15.264	f	Friend	t	\N	2026-04-14 04:33:57.797	2026-04-18 19:03:15.266
\.


--
-- Data for Name: VerificationCode; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."VerificationCode" (id, email, code, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: WeeklyProgress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."WeeklyProgress" (id, "userId", "weekStartDate", "perfectScoresCount", "progressPercentage") FROM stdin;
\.


--
-- Data for Name: _Staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."_Staff" ("A", "B") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
d19def53-4306-41d4-a876-1f66f79f0bb9	dbf348fc780b35b9cfe2baa37d4eed4981e0e45a5f91e2dea047810ba381172d	2026-04-14 09:28:04.136235+05	20260413170304_init	\N	\N	2026-04-14 09:28:03.819479+05	1
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.announcements (id, title, content, type, "isActive", "createdAt", "updatedAt", "createdBy") FROM stdin;
\.


--
-- Data for Name: centres; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.centres (id, name, code, city, address, phone, website, "totalStudents", "activeStudents", rating, "isActive", "createdAt", "updatedAt", country, email, "managerId", latitude, longitude) FROM stdin;
1	British Council Tashkent	BC-TAS	Tashkent	107 Amir Temur Avenue	+998 71 1234567	https://britishcouncil.uz	0	0	4.8	t	2026-04-14 04:29:40.585	2026-04-14 04:29:40.585	Uzbekistan	\N	\N	41.3111	69.2406
2	IDP IELTS Tashkent	IDP-TAS-01	Tashkent	45 Oybek Street, Tashkent	+998 71 2000202	https://idp.uz	0	0	4.7	t	2026-04-14 04:29:40.596	2026-04-14 04:29:40.596	Uzbekistan	\N	\N	41.2995	69.2664
3	IELTS Zone Tashkent	IZ-TAS-01	Tashkent	Chilonzor 1, Tashkent	+998 90 1234567	https://ieltszone.uz	0	0	4.9	t	2026-04-14 04:29:40.608	2026-04-14 04:29:40.608	Uzbekistan	\N	\N	41.2827	69.2041
4	Innovative Centre Samarkand	INN-SAM	Samarkand	12 Registon Street	+998 66 1234567	https://innovative.uz	0	0	4.9	t	2026-04-14 04:29:40.619	2026-04-14 04:29:40.619	Uzbekistan	\N	\N	39.6542	66.9597
5	Education First Bukhara	EF-BUK-01	Bukhara	B. Naqshband Street, Bukhara	+998 65 1234567	https://efbukhara.uz	0	0	4.5	t	2026-04-14 04:29:40.63	2026-04-14 04:29:40.63	Uzbekistan	\N	\N	39.7747	64.4286
\.


--
-- Data for Name: live_session_participants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.live_session_participants (id, "sessionId", "userId", "joinedAt", "leftAt", role, "createdAt") FROM stdin;
\.


--
-- Data for Name: live_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.live_sessions (id, title, description, "teacherId", "sessionType", "startTime", "endTime", "maxParticipants", status, "isFeatured", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- Data for Name: test_submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_submissions (id, "userId", "testId", "testType", answers, score, "bandScore", "timeSpent", "submittedAt", "gradedAt", feedback) FROM stdin;
\.


--
-- Data for Name: typing_practice_texts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.typing_practice_texts (id, title, content, difficulty, "wordCount", topics, "isActive", "createdAt", "updatedAt") FROM stdin;
cmny4g3ps0000j2w9w2sk8zcn	Architecture and Sustainability	The development of sustainable architecture has become increasingly vital in recent years. Architects are now focusing on creating buildings that minimize environmental impact through efficient use of energy, water, and materials. This involves incorporating renewable energy sources, such as solar panels and wind turbines, and utilizing recycled or locally sourced materials. Furthermore, sustainable design often includes features like green roofs and natural ventilation systems to reduce the need for artificial heating and cooling. As urbanization continues to rise, the integration of sustainability into architectural practices is essential for mitigating climate change and promoting a healthier, more resilient built environment for future generations.	intermediate	118	Academic,Environment,Architecture	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3ps0001j2w9zz15w5t8	Climate Change Solutions	Global warming represents one of the most pressing challenges facing humanity today. Addressing this complex issue requires a multi-faceted approach involving international cooperation, technological innovation, and individual action. One key strategy is the transition from fossil fuels to clean, renewable energy sources like wind, solar, and hydroelectric power. Additionally, reforestation and the protection of existing forests play a crucial role in absorbing carbon dioxide from the atmosphere. Governments can also implement policies such as carbon pricing and stricter emission standards for industries. Ultimately, a combination of large-scale systemic changes and everyday sustainable choices is necessary to reduce greenhouse gas emissions and protect our planet's future.	advanced	120	Environment,Science,Climate	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3ps0002j2w9sbnk0jum	The Importance of Biodiversity	Biodiversity is the variety of life on Earth, encompassing all species of plants, animals, and microorganisms, as well as the ecosystems they form. It provides essential services that support human life, including food production, water purification, and climate regulation. However, human activities such as habitat destruction, pollution, and overexploitation are leading to an unprecedented rate of species extinction. Protecting biodiversity is not only a moral imperative but also a practical necessity for maintaining the stability and productivity of our planet. Conservation efforts must focus on preserving natural habitats, restoring degraded ecosystems, and promoting sustainable management of natural resources to ensure that future generations can continue to benefit from the richness of life on Earth.	advanced	124	Biology,Environment,Nature	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3ps0003j2w9l5dtbhp0	Digital Transformation in Education	The landscape of education is undergoing a profound transformation driven by digital technology. Online learning platforms, interactive software, and mobile applications are providing students with unprecedented access to information and educational resources. This shift allows for more personalized learning experiences, as students can progress at their own pace and explore topics that interest them. Teachers are also using digital tools to enhance classroom instruction and facilitate collaboration among students. While digital transformation offers many benefits, it also presents challenges, such as the digital divide and the need for new pedagogical approaches. Ensuring that all students have equal access to technology and developing digital literacy skills are crucial for preparing them for success in the 21st century.	intermediate	130	Technology,Education,Digital	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3pt0004j2w97pqb5tqx	The History of the Olympic Games	The Olympic Games have a long and storied history, dating back to ancient Greece. The first recorded Olympic Games were held in 776 BC in Olympia, as a festival to honor the god Zeus. These ancient games featured various athletic competitions, including running, wrestling, and chariot racing. The modern Olympic Games were revived in 1896 by Pierre de Coubertin, who envisioned them as a way to promote international understanding and peace through sport. Today, the Olympics are a global event, bringing together thousands of athletes from around the world to compete in a wide range of summer and winter sports. The Games continue to inspire people with their message of excellence, friendship, and respect.	beginner	128	History,Sports,Culture	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3pt0005j2w984mqz3ma	The Benefits of Regular Exercise	Regular physical activity is one of the most important things you can do for your health. It can help you manage your weight, reduce your risk of chronic diseases such as heart disease and diabetes, and strengthen your bones and muscles. Exercise also has significant mental health benefits, including reducing stress, anxiety, and depression. Whether it's a brisk walk, a swim, or a yoga session, finding an activity you enjoy and making it a part of your daily routine can greatly improve your overall well-being. Aim for at least 150 minutes of moderate-intensity aerobic activity per week, along with muscle-strengthening activities on two or more days. The rewards of staying active are well worth the effort.	beginner	126	Health,Fitness,Lifestyle	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3pt0006j2w98e5aqcz7	Artificial Intelligence in Healthcare	Artificial Intelligence (AI) is revolutionizing the healthcare industry by enhancing diagnostic accuracy, personalizing treatment plans, and improving patient outcomes. AI algorithms can analyze vast amounts of medical data, including imaging and genomic information, to identify patterns that might be missed by human clinicians. This technology is being used to detect diseases like cancer at earlier stages and to develop more effective drugs and therapies. Furthermore, AI-powered virtual assistants and chatbots are providing patients with 24/7 support and personalized health advice. While AI offers immense potential, it also raises ethical concerns regarding data privacy and the role of human judgment in medical decision-making. As AI continues to evolve, its integration into healthcare must be carefully managed to ensure it benefits all patients.	advanced	132	Technology,Healthcare,AI	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4g3pt0007j2w9nnmwjws4	The Future of Space Exploration	Space exploration has entered a new era, with both government agencies and private companies working to reach new frontiers. Missions to Mars, the establishment of lunar bases, and the search for extraterrestrial life are among the ambitious goals of current and future space programs. Advances in rocket technology and robotics are making these missions more feasible and cost-effective. Additionally, space exploration has the potential to yield significant scientific discoveries and technological innovations that can benefit life on Earth. However, the challenges of long-duration space travel, including radiation exposure and resource management, remain significant. As we look to the stars, international collaboration and a shared vision for the peaceful use of space will be essential for the continued success of our journey into the cosmos.	intermediate	134	Science,Space,Future	t	2026-04-14 04:28:43.601	2026-04-14 04:28:43.601
cmny4gqeh0000j27pkwoz1b0m	Architecture and Sustainability	The development of sustainable architecture has become increasingly vital in recent years. Architects are now focusing on creating buildings that minimize environmental impact through efficient use of energy, water, and materials. This involves incorporating renewable energy sources, such as solar panels and wind turbines, and utilizing recycled or locally sourced materials. Furthermore, sustainable design often includes features like green roofs and natural ventilation systems to reduce the need for artificial heating and cooling. As urbanization continues to rise, the integration of sustainability into architectural practices is essential for mitigating climate change and promoting a healthier, more resilient built environment for future generations.	intermediate	118	Academic,Environment,Architecture	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0001j27pj3xm6eb2	Climate Change Solutions	Global warming represents one of the most pressing challenges facing humanity today. Addressing this complex issue requires a multi-faceted approach involving international cooperation, technological innovation, and individual action. One key strategy is the transition from fossil fuels to clean, renewable energy sources like wind, solar, and hydroelectric power. Additionally, reforestation and the protection of existing forests play a crucial role in absorbing carbon dioxide from the atmosphere. Governments can also implement policies such as carbon pricing and stricter emission standards for industries. Ultimately, a combination of large-scale systemic changes and everyday sustainable choices is necessary to reduce greenhouse gas emissions and protect our planet's future.	advanced	120	Environment,Science,Climate	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0002j27pp7351139	The Importance of Biodiversity	Biodiversity is the variety of life on Earth, encompassing all species of plants, animals, and microorganisms, as well as the ecosystems they form. It provides essential services that support human life, including food production, water purification, and climate regulation. However, human activities such as habitat destruction, pollution, and overexploitation are leading to an unprecedented rate of species extinction. Protecting biodiversity is not only a moral imperative but also a practical necessity for maintaining the stability and productivity of our planet. Conservation efforts must focus on preserving natural habitats, restoring degraded ecosystems, and promoting sustainable management of natural resources to ensure that future generations can continue to benefit from the richness of life on Earth.	advanced	124	Biology,Environment,Nature	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0003j27pe2t2t5gn	Digital Transformation in Education	The landscape of education is undergoing a profound transformation driven by digital technology. Online learning platforms, interactive software, and mobile applications are providing students with unprecedented access to information and educational resources. This shift allows for more personalized learning experiences, as students can progress at their own pace and explore topics that interest them. Teachers are also using digital tools to enhance classroom instruction and facilitate collaboration among students. While digital transformation offers many benefits, it also presents challenges, such as the digital divide and the need for new pedagogical approaches. Ensuring that all students have equal access to technology and developing digital literacy skills are crucial for preparing them for success in the 21st century.	intermediate	130	Technology,Education,Digital	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0004j27p9mxprgdb	The History of the Olympic Games	The Olympic Games have a long and storied history, dating back to ancient Greece. The first recorded Olympic Games were held in 776 BC in Olympia, as a festival to honor the god Zeus. These ancient games featured various athletic competitions, including running, wrestling, and chariot racing. The modern Olympic Games were revived in 1896 by Pierre de Coubertin, who envisioned them as a way to promote international understanding and peace through sport. Today, the Olympics are a global event, bringing together thousands of athletes from around the world to compete in a wide range of summer and winter sports. The Games continue to inspire people with their message of excellence, friendship, and respect.	beginner	128	History,Sports,Culture	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0005j27pnqm6wzmp	The Benefits of Regular Exercise	Regular physical activity is one of the most important things you can do for your health. It can help you manage your weight, reduce your risk of chronic diseases such as heart disease and diabetes, and strengthen your bones and muscles. Exercise also has significant mental health benefits, including reducing stress, anxiety, and depression. Whether it's a brisk walk, a swim, or a yoga session, finding an activity you enjoy and making it a part of your daily routine can greatly improve your overall well-being. Aim for at least 150 minutes of moderate-intensity aerobic activity per week, along with muscle-strengthening activities on two or more days. The rewards of staying active are well worth the effort.	beginner	126	Health,Fitness,Lifestyle	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0006j27p4wl9ax3y	Artificial Intelligence in Healthcare	Artificial Intelligence (AI) is revolutionizing the healthcare industry by enhancing diagnostic accuracy, personalizing treatment plans, and improving patient outcomes. AI algorithms can analyze vast amounts of medical data, including imaging and genomic information, to identify patterns that might be missed by human clinicians. This technology is being used to detect diseases like cancer at earlier stages and to develop more effective drugs and therapies. Furthermore, AI-powered virtual assistants and chatbots are providing patients with 24/7 support and personalized health advice. While AI offers immense potential, it also raises ethical concerns regarding data privacy and the role of human judgment in medical decision-making. As AI continues to evolve, its integration into healthcare must be carefully managed to ensure it benefits all patients.	advanced	132	Technology,Healthcare,AI	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4gqeh0007j27pinheyc0t	The Future of Space Exploration	Space exploration has entered a new era, with both government agencies and private companies working to reach new frontiers. Missions to Mars, the establishment of lunar bases, and the search for extraterrestrial life are among the ambitious goals of current and future space programs. Advances in rocket technology and robotics are making these missions more feasible and cost-effective. Additionally, space exploration has the potential to yield significant scientific discoveries and technological innovations that can benefit life on Earth. However, the challenges of long-duration space travel, including radiation exposure and resource management, remain significant. As we look to the stars, international collaboration and a shared vision for the peaceful use of space will be essential for the continued success of our journey into the cosmos.	intermediate	134	Science,Space,Future	t	2026-04-14 04:29:13.001	2026-04-14 04:29:13.001
cmny4hboe0000j2qm2j4ahhzk	Architecture and Sustainability	The development of sustainable architecture has become increasingly vital in recent years. Architects are now focusing on creating buildings that minimize environmental impact through efficient use of energy, water, and materials. This involves incorporating renewable energy sources, such as solar panels and wind turbines, and utilizing recycled or locally sourced materials. Furthermore, sustainable design often includes features like green roofs and natural ventilation systems to reduce the need for artificial heating and cooling. As urbanization continues to rise, the integration of sustainability into architectural practices is essential for mitigating climate change and promoting a healthier, more resilient built environment for future generations.	intermediate	118	Academic,Environment,Architecture	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0001j2qme0jlzcct	Climate Change Solutions	Global warming represents one of the most pressing challenges facing humanity today. Addressing this complex issue requires a multi-faceted approach involving international cooperation, technological innovation, and individual action. One key strategy is the transition from fossil fuels to clean, renewable energy sources like wind, solar, and hydroelectric power. Additionally, reforestation and the protection of existing forests play a crucial role in absorbing carbon dioxide from the atmosphere. Governments can also implement policies such as carbon pricing and stricter emission standards for industries. Ultimately, a combination of large-scale systemic changes and everyday sustainable choices is necessary to reduce greenhouse gas emissions and protect our planet's future.	advanced	120	Environment,Science,Climate	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0002j2qm5a0f3fan	The Importance of Biodiversity	Biodiversity is the variety of life on Earth, encompassing all species of plants, animals, and microorganisms, as well as the ecosystems they form. It provides essential services that support human life, including food production, water purification, and climate regulation. However, human activities such as habitat destruction, pollution, and overexploitation are leading to an unprecedented rate of species extinction. Protecting biodiversity is not only a moral imperative but also a practical necessity for maintaining the stability and productivity of our planet. Conservation efforts must focus on preserving natural habitats, restoring degraded ecosystems, and promoting sustainable management of natural resources to ensure that future generations can continue to benefit from the richness of life on Earth.	advanced	124	Biology,Environment,Nature	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0003j2qm1o5y7yqc	Digital Transformation in Education	The landscape of education is undergoing a profound transformation driven by digital technology. Online learning platforms, interactive software, and mobile applications are providing students with unprecedented access to information and educational resources. This shift allows for more personalized learning experiences, as students can progress at their own pace and explore topics that interest them. Teachers are also using digital tools to enhance classroom instruction and facilitate collaboration among students. While digital transformation offers many benefits, it also presents challenges, such as the digital divide and the need for new pedagogical approaches. Ensuring that all students have equal access to technology and developing digital literacy skills are crucial for preparing them for success in the 21st century.	intermediate	130	Technology,Education,Digital	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0004j2qmhp40mi32	The History of the Olympic Games	The Olympic Games have a long and storied history, dating back to ancient Greece. The first recorded Olympic Games were held in 776 BC in Olympia, as a festival to honor the god Zeus. These ancient games featured various athletic competitions, including running, wrestling, and chariot racing. The modern Olympic Games were revived in 1896 by Pierre de Coubertin, who envisioned them as a way to promote international understanding and peace through sport. Today, the Olympics are a global event, bringing together thousands of athletes from around the world to compete in a wide range of summer and winter sports. The Games continue to inspire people with their message of excellence, friendship, and respect.	beginner	128	History,Sports,Culture	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0005j2qml4fftvs3	The Benefits of Regular Exercise	Regular physical activity is one of the most important things you can do for your health. It can help you manage your weight, reduce your risk of chronic diseases such as heart disease and diabetes, and strengthen your bones and muscles. Exercise also has significant mental health benefits, including reducing stress, anxiety, and depression. Whether it's a brisk walk, a swim, or a yoga session, finding an activity you enjoy and making it a part of your daily routine can greatly improve your overall well-being. Aim for at least 150 minutes of moderate-intensity aerobic activity per week, along with muscle-strengthening activities on two or more days. The rewards of staying active are well worth the effort.	beginner	126	Health,Fitness,Lifestyle	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0006j2qmitwaia84	Artificial Intelligence in Healthcare	Artificial Intelligence (AI) is revolutionizing the healthcare industry by enhancing diagnostic accuracy, personalizing treatment plans, and improving patient outcomes. AI algorithms can analyze vast amounts of medical data, including imaging and genomic information, to identify patterns that might be missed by human clinicians. This technology is being used to detect diseases like cancer at earlier stages and to develop more effective drugs and therapies. Furthermore, AI-powered virtual assistants and chatbots are providing patients with 24/7 support and personalized health advice. While AI offers immense potential, it also raises ethical concerns regarding data privacy and the role of human judgment in medical decision-making. As AI continues to evolve, its integration into healthcare must be carefully managed to ensure it benefits all patients.	advanced	132	Technology,Healthcare,AI	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
cmny4hboe0007j2qmhyzdt215	The Future of Space Exploration	Space exploration has entered a new era, with both government agencies and private companies working to reach new frontiers. Missions to Mars, the establishment of lunar bases, and the search for extraterrestrial life are among the ambitious goals of current and future space programs. Advances in rocket technology and robotics are making these missions more feasible and cost-effective. Additionally, space exploration has the potential to yield significant scientific discoveries and technological innovations that can benefit life on Earth. However, the challenges of long-duration space travel, including radiation exposure and resource management, remain significant. As we look to the stars, international collaboration and a shared vision for the peaceful use of space will be essential for the continued success of our journey into the cosmos.	intermediate	134	Science,Space,Future	t	2026-04-14 04:29:40.574	2026-04-14 04:29:40.574
\.


--
-- Data for Name: user_progress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_progress (id, "userId", "testType", "latestScore", "testsCompleted", "lastTestDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: AdminTask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AdminTask_id_seq"', 1, false);


--
-- Name: AiChatSession_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AiChatSession_id_seq"', 1, false);


--
-- Name: Device_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Device_id_seq"', 1, false);


--
-- Name: Follow_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Follow_id_seq"', 1, false);


--
-- Name: GroupApplication_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."GroupApplication_id_seq"', 1, false);


--
-- Name: Inquiry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Inquiry_id_seq"', 1, false);


--
-- Name: Lesson_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Lesson_id_seq"', 1, false);


--
-- Name: LoginLog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LoginLog_id_seq"', 1, false);


--
-- Name: Material_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Material_id_seq"', 1, false);


--
-- Name: MockResult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MockResult_id_seq"', 1, false);


--
-- Name: MockSession_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MockSession_id_seq"', 1, false);


--
-- Name: Notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Notification_id_seq"', 1, false);


--
-- Name: PartnerRequest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PartnerRequest_id_seq"', 1, false);


--
-- Name: PasswordResetToken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PasswordResetToken_id_seq"', 1, false);


--
-- Name: PracticeTestResult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PracticeTestResult_id_seq"', 1, false);


--
-- Name: PracticeTest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."PracticeTest_id_seq"', 1, false);


--
-- Name: ProgressSnapshot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ProgressSnapshot_id_seq"', 1, false);


--
-- Name: Question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Question_id_seq"', 1, false);


--
-- Name: Report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Report_id_seq"', 1, false);


--
-- Name: StrategicGoal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."StrategicGoal_id_seq"', 1, false);


--
-- Name: StudyGroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."StudyGroup_id_seq"', 1, false);


--
-- Name: StudyStreak_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."StudyStreak_id_seq"', 1, false);


--
-- Name: TestUnlock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TestUnlock_id_seq"', 1, false);


--
-- Name: TypingResult_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TypingResult_id_seq"', 1, false);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 9, true);


--
-- Name: VerificationCode_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VerificationCode_id_seq"', 2, true);


--
-- Name: WeeklyProgress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."WeeklyProgress_id_seq"', 1, false);


--
-- Name: centres_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.centres_id_seq', 5, true);


--
-- Name: AdminTask AdminTask_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminTask"
    ADD CONSTRAINT "AdminTask_pkey" PRIMARY KEY (id);


--
-- Name: AiChatSession AiChatSession_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AiChatSession"
    ADD CONSTRAINT "AiChatSession_pkey" PRIMARY KEY (id);


--
-- Name: Device Device_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_pkey" PRIMARY KEY (id);


--
-- Name: Follow Follow_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_pkey" PRIMARY KEY (id);


--
-- Name: GroupApplication GroupApplication_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_pkey" PRIMARY KEY (id);


--
-- Name: Inquiry Inquiry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inquiry"
    ADD CONSTRAINT "Inquiry_pkey" PRIMARY KEY (id);


--
-- Name: Lesson Lesson_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_pkey" PRIMARY KEY (id);


--
-- Name: LoginLog LoginLog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_pkey" PRIMARY KEY (id);


--
-- Name: Material Material_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Material"
    ADD CONSTRAINT "Material_pkey" PRIMARY KEY (id);


--
-- Name: MockResult MockResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockResult"
    ADD CONSTRAINT "MockResult_pkey" PRIMARY KEY (id);


--
-- Name: MockSession MockSession_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockSession"
    ADD CONSTRAINT "MockSession_pkey" PRIMARY KEY (id);


--
-- Name: Notification Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id);


--
-- Name: PartnerRequest PartnerRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PartnerRequest"
    ADD CONSTRAINT "PartnerRequest_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: PracticeTestResult PracticeTestResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTestResult"
    ADD CONSTRAINT "PracticeTestResult_pkey" PRIMARY KEY (id);


--
-- Name: PracticeTest PracticeTest_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTest"
    ADD CONSTRAINT "PracticeTest_pkey" PRIMARY KEY (id);


--
-- Name: ProgressSnapshot ProgressSnapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProgressSnapshot"
    ADD CONSTRAINT "ProgressSnapshot_pkey" PRIMARY KEY (id);


--
-- Name: Question Question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (id);


--
-- Name: Report Report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_pkey" PRIMARY KEY (id);


--
-- Name: StrategicGoal StrategicGoal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StrategicGoal"
    ADD CONSTRAINT "StrategicGoal_pkey" PRIMARY KEY (id);


--
-- Name: StudyGroup StudyGroup_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyGroup"
    ADD CONSTRAINT "StudyGroup_pkey" PRIMARY KEY (id);


--
-- Name: StudyStreak StudyStreak_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyStreak"
    ADD CONSTRAINT "StudyStreak_pkey" PRIMARY KEY (id);


--
-- Name: TestUnlock TestUnlock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TestUnlock"
    ADD CONSTRAINT "TestUnlock_pkey" PRIMARY KEY (id);


--
-- Name: TypingResult TypingResult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TypingResult"
    ADD CONSTRAINT "TypingResult_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: VerificationCode VerificationCode_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VerificationCode"
    ADD CONSTRAINT "VerificationCode_pkey" PRIMARY KEY (id);


--
-- Name: WeeklyProgress WeeklyProgress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WeeklyProgress"
    ADD CONSTRAINT "WeeklyProgress_pkey" PRIMARY KEY (id);


--
-- Name: _Staff _Staff_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_Staff"
    ADD CONSTRAINT "_Staff_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: centres centres_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centres
    ADD CONSTRAINT centres_pkey PRIMARY KEY (id);


--
-- Name: live_session_participants live_session_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_session_participants
    ADD CONSTRAINT live_session_participants_pkey PRIMARY KEY (id);


--
-- Name: live_sessions live_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT live_sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: test_submissions test_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_submissions
    ADD CONSTRAINT test_submissions_pkey PRIMARY KEY (id);


--
-- Name: typing_practice_texts typing_practice_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.typing_practice_texts
    ADD CONSTRAINT typing_practice_texts_pkey PRIMARY KEY (id);


--
-- Name: user_progress user_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT user_progress_pkey PRIMARY KEY (id);


--
-- Name: AdminTask_adminId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AdminTask_adminId_idx" ON public."AdminTask" USING btree ("adminId");


--
-- Name: AdminTask_isDone_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "AdminTask_isDone_idx" ON public."AdminTask" USING btree ("isDone");


--
-- Name: Device_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "Device_userId_idx" ON public."Device" USING btree ("userId");


--
-- Name: Follow_studentId_teacherId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "Follow_studentId_teacherId_key" ON public."Follow" USING btree ("studentId", "teacherId");


--
-- Name: GroupApplication_studentId_groupId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "GroupApplication_studentId_groupId_key" ON public."GroupApplication" USING btree ("studentId", "groupId");


--
-- Name: LoginLog_timestamp_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "LoginLog_timestamp_idx" ON public."LoginLog" USING btree ("timestamp");


--
-- Name: LoginLog_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "LoginLog_userId_idx" ON public."LoginLog" USING btree ("userId");


--
-- Name: PartnerRequest_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PartnerRequest_email_key" ON public."PartnerRequest" USING btree (email);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: PracticeTestResult_testCategory_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PracticeTestResult_testCategory_idx" ON public."PracticeTestResult" USING btree ("testCategory");


--
-- Name: PracticeTestResult_testIdentifier_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PracticeTestResult_testIdentifier_idx" ON public."PracticeTestResult" USING btree ("testIdentifier");


--
-- Name: PracticeTestResult_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PracticeTestResult_userId_idx" ON public."PracticeTestResult" USING btree ("userId");


--
-- Name: PracticeTestResult_userId_testIdentifier_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "PracticeTestResult_userId_testIdentifier_key" ON public."PracticeTestResult" USING btree ("userId", "testIdentifier");


--
-- Name: PracticeTest_testType_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "PracticeTest_testType_idx" ON public."PracticeTest" USING btree ("testType");


--
-- Name: ProgressSnapshot_snapshotDate_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProgressSnapshot_snapshotDate_idx" ON public."ProgressSnapshot" USING btree ("snapshotDate");


--
-- Name: ProgressSnapshot_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ProgressSnapshot_userId_idx" ON public."ProgressSnapshot" USING btree ("userId");


--
-- Name: StudyStreak_userId_date_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "StudyStreak_userId_date_key" ON public."StudyStreak" USING btree ("userId", date);


--
-- Name: TestUnlock_userId_category_subcategory_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "TestUnlock_userId_category_subcategory_key" ON public."TestUnlock" USING btree ("userId", category, subcategory);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: WeeklyProgress_userId_weekStartDate_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "WeeklyProgress_userId_weekStartDate_key" ON public."WeeklyProgress" USING btree ("userId", "weekStartDate");


--
-- Name: _Staff_B_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "_Staff_B_index" ON public."_Staff" USING btree ("B");


--
-- Name: accounts_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "accounts_provider_providerAccountId_key" ON public.accounts USING btree (provider, "providerAccountId");


--
-- Name: centres_city_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX centres_city_idx ON public.centres USING btree (city);


--
-- Name: centres_code_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX centres_code_idx ON public.centres USING btree (code);


--
-- Name: centres_code_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX centres_code_key ON public.centres USING btree (code);


--
-- Name: centres_latitude_longitude_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX centres_latitude_longitude_idx ON public.centres USING btree (latitude, longitude);


--
-- Name: centres_name_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX centres_name_key ON public.centres USING btree (name);


--
-- Name: live_session_participants_sessionId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "live_session_participants_sessionId_idx" ON public.live_session_participants USING btree ("sessionId");


--
-- Name: live_session_participants_sessionId_userId_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "live_session_participants_sessionId_userId_key" ON public.live_session_participants USING btree ("sessionId", "userId");


--
-- Name: live_session_participants_userId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "live_session_participants_userId_idx" ON public.live_session_participants USING btree ("userId");


--
-- Name: live_sessions_startTime_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "live_sessions_startTime_idx" ON public.live_sessions USING btree ("startTime");


--
-- Name: live_sessions_teacherId_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "live_sessions_teacherId_idx" ON public.live_sessions USING btree ("teacherId");


--
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- Name: typing_practice_texts_difficulty_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX typing_practice_texts_difficulty_idx ON public.typing_practice_texts USING btree (difficulty);


--
-- Name: typing_practice_texts_isActive_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "typing_practice_texts_isActive_idx" ON public.typing_practice_texts USING btree ("isActive");


--
-- Name: user_progress_userId_testType_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "user_progress_userId_testType_key" ON public.user_progress USING btree ("userId", "testType");


--
-- Name: AdminTask AdminTask_adminId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AdminTask"
    ADD CONSTRAINT "AdminTask_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AiChatSession AiChatSession_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AiChatSession"
    ADD CONSTRAINT "AiChatSession_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Device Device_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Device"
    ADD CONSTRAINT "Device_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Follow Follow_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Follow Follow_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Follow"
    ADD CONSTRAINT "Follow_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GroupApplication GroupApplication_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public."StudyGroup"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: GroupApplication GroupApplication_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."GroupApplication"
    ADD CONSTRAINT "GroupApplication_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Inquiry Inquiry_centreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Inquiry"
    ADD CONSTRAINT "Inquiry_centreId_fkey" FOREIGN KEY ("centreId") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Lesson Lesson_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Lesson"
    ADD CONSTRAINT "Lesson_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: LoginLog LoginLog_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LoginLog"
    ADD CONSTRAINT "LoginLog_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Material Material_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Material"
    ADD CONSTRAINT "Material_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public."Lesson"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Material Material_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Material"
    ADD CONSTRAINT "Material_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MockResult MockResult_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockResult"
    ADD CONSTRAINT "MockResult_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public."MockSession"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: MockResult MockResult_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockResult"
    ADD CONSTRAINT "MockResult_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: MockSession MockSession_centreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MockSession"
    ADD CONSTRAINT "MockSession_centreId_fkey" FOREIGN KEY ("centreId") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PracticeTestResult PracticeTestResult_testId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTestResult"
    ADD CONSTRAINT "PracticeTestResult_testId_fkey" FOREIGN KEY ("testId") REFERENCES public."PracticeTest"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PracticeTestResult PracticeTestResult_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTestResult"
    ADD CONSTRAINT "PracticeTestResult_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PracticeTest PracticeTest_createdById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."PracticeTest"
    ADD CONSTRAINT "PracticeTest_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ProgressSnapshot ProgressSnapshot_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ProgressSnapshot"
    ADD CONSTRAINT "ProgressSnapshot_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Question Question_testId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_testId_fkey" FOREIGN KEY ("testId") REFERENCES public."PracticeTest"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Report Report_questionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_questionId_fkey" FOREIGN KEY ("questionId") REFERENCES public."Question"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Report Report_resolvedById_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_resolvedById_fkey" FOREIGN KEY ("resolvedById") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Report Report_studentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_studentId_fkey" FOREIGN KEY ("studentId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Report Report_testId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report"
    ADD CONSTRAINT "Report_testId_fkey" FOREIGN KEY ("testId") REFERENCES public."PracticeTest"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: StudyGroup StudyGroup_centreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyGroup"
    ADD CONSTRAINT "StudyGroup_centreId_fkey" FOREIGN KEY ("centreId") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: StudyGroup StudyGroup_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyGroup"
    ADD CONSTRAINT "StudyGroup_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: StudyStreak StudyStreak_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."StudyStreak"
    ADD CONSTRAINT "StudyStreak_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TestUnlock TestUnlock_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TestUnlock"
    ADD CONSTRAINT "TestUnlock_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TypingResult TypingResult_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TypingResult"
    ADD CONSTRAINT "TypingResult_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: User User_centreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_centreId_fkey" FOREIGN KEY ("centreId") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: WeeklyProgress WeeklyProgress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."WeeklyProgress"
    ADD CONSTRAINT "WeeklyProgress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _Staff _Staff_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_Staff"
    ADD CONSTRAINT "_Staff_A_fkey" FOREIGN KEY ("A") REFERENCES public.centres(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _Staff _Staff_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."_Staff"
    ADD CONSTRAINT "_Staff_B_fkey" FOREIGN KEY ("B") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: announcements announcements_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT "announcements_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: centres centres_managerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.centres
    ADD CONSTRAINT "centres_managerId_fkey" FOREIGN KEY ("managerId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: live_session_participants live_session_participants_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_session_participants
    ADD CONSTRAINT "live_session_participants_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.live_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: live_session_participants live_session_participants_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_session_participants
    ADD CONSTRAINT "live_session_participants_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: live_sessions live_sessions_teacherId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.live_sessions
    ADD CONSTRAINT "live_sessions_teacherId_fkey" FOREIGN KEY ("teacherId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: test_submissions test_submissions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_submissions
    ADD CONSTRAINT "test_submissions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_progress user_progress_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_progress
    ADD CONSTRAINT "user_progress_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict 53hBTjhUWzkal73CNuqSBIQ8irv4MPzK3IdavEWcdW0KP3Do2aeGoArKQuSBBLt

